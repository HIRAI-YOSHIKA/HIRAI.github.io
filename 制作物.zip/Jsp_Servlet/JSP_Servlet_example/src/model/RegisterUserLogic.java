package model;

public class RegisterUserLogic {
	public boolean execute(User user){

		return true;
	}
}
