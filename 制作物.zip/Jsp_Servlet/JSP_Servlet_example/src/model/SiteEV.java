package model;

import java.io.Serializable;

public class SiteEV implements Serializable {
	private int like;
	private int dislike;
	private int bat;


	public SiteEV() {

		like = 0;
		dislike = 0;
		bat = 0;
	}


	public int getBat() {
		return bat;
	}


	public void setBat(int bat) {
		this.bat = bat;
	}


	public int getLike() {
		return like;
	}


	public void setLike(int like) {
		this.like = like;
	}


	public int getDislike() {
		return dislike;
	}


	public void setDislike(int dislike) {
		this.dislike = dislike;
	}



}