package model;

import java.io.Serializable;

public class User implements Serializable {

	private String id;
	private String name;
	private String pass;

	public User () { }

	public User(String id, String name, String pass) {
		setId(id);
		setName(name);
		setPass(pass);
	}

	public String getId() {
		return this.id ;
	}

	public String getName() {
		return this.name;
	}

	public String getPass() {
		return this.pass;
	}

	public void setId(String id) {

		String errorMsg = "";

		if (id.length() < 5 || id.length() == 0) {

				errorMsg += "5文字以上で入力して下さい";
			}
		this.id = id;

	}

	public void setName(String name) {


		String errorMsg = "";
		if (name == null || name.length() == 0) {
				errorMsg += "名前を入力してください。";
			}
		this.name = name;
	}

	public void setPass(String pass) {


		String errorMsg = "";

		if (pass == null || pass.length() == 0) {
				//throw new iliegalArgumentExsep
			}
		this.pass = pass;
	};



}
