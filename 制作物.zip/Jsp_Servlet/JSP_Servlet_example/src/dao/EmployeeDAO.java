package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Employee;

public class EmployeeDAO {
	// 接続環境 localhostの後に自分で作ったデータベース名をいれる
	String url = "jdbc:mysql://localhost/practice_db_hirai?useUnicode=true&characterEncoding=utf8";
	String user = "root";
	String password = "root";

	public List<Employee> findAll() {

		// returnするリストを用意
		List<Employee> emplist = new ArrayList<>();

		//お約束：Connection型変数の宣言
		Connection conn = null;

		// DBが関わる処理は指定された例外のtry-catchが必須
		// MAMPで用意したデータベースに接続
		//finallyでの切断処理も必ず付けておこう
		try {
			//JDBCドライバを読み込み
			Class.forName("com.mysql.jdbc.Driver");

			//MAMPで用意したデータベースに接続
			//DBMSへの接続や切断を行うconnection型インスタンスに設定を代入
			//引数の意味は( DBにアクセスするためのパス＋文字コード設定 , ユーザー名 , パスワード )
			conn = DriverManager.getConnection(url, user, password);

			//String型変数にクエリ(問い合わせ)を用意 サーバーから取り出したい情報
			String sql = "SELECT ID,NAME,AGE FROM EMPLOYEE";

			//Connection.prepareStatement(用意したクエリ)メソッドを使って、
			//用意したSQLをDBに届けるためのPreparedStatement型インスタンスを作成
			PreparedStatement ps = conn.prepareStatement(sql);

			//PreparedStatement.executeQuery()メソッドでクエリを実行し、
			//ResultSet型インスタンス(変数rs)に結果が格納される
			//結果　　　　　　　実行
			ResultSet rs = ps.executeQuery();

			//rs.next()取得結果が存在するかどうかを表すbool値)で条件分岐や繰り返しを行い、
			//ResultSetから情報を引き出す
			//rsの中身を順番に取り出す
			while (rs.next()) {

				// DBのカラム
				String id = rs.getString("ID");
				String name = rs.getString("NAME");
				int age = rs.getInt("AGE");

				Employee employee = new Employee( id, name, age);
				emplist.add(employee);

			}
			// エラーをキャッチ
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally {
			// DBMSへの接続があるなら
			if (conn != null) {
				try {
					// DBMSの接続を切断
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} // try

		return emplist;

	}//findAll

}//class
