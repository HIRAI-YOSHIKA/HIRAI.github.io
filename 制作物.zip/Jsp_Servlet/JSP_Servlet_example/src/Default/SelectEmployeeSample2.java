﻿package Default;

import java.sql.Connection;        //DBMSへの接続や切断を行う
import java.sql.DriverManager;     //DBMSへの接続準備を行う
import java.sql.PreparedStatement; //SQLの送信を行う
import java.sql.ResultSet;         //DBMSから検査結果を受け取る
import java.sql.SQLException;      //データベースに関するエラーの情報を提供する


public class SelectEmployeeSample2 {

	public static void main(String[] args) {

		// 接続環境 localhostの後に自分で作ったデータベース名をいれる
		String url = "jdbc:mysql://localhost/practice_db_hirai?useUnicode=true&characterEncoding=utf8";
		String user = "root";
		String password = "root";


		//お約束：Connection型変数の宣言
		Connection conn = null;


		// DBが関わる処理は指定された例外のtry-catchが必須
		// MAMPで用意したデータベースに接続
		//finallyでの切断処理も必ず付けておこう
		try {

			//JDBCドライバを読み込み
			Class.forName("com.mysql.jdbc.Driver");


			//MAMPで用意したデータベースに接続
			//DBMSへの接続や切断を行うconnection型インスタンスに設定を代入
			//引数の意味は( DBにアクセスするためのパス＋文字コード設定 , ユーザー名 , パスワード )
			conn = DriverManager.getConnection(url, user, password);


			//String型変数にクエリ(問い合わせ)を用意
			String sql = "SELECT ID,NAME,AGE FROM EMPLOYEE";


			//Connection.prepareStatement(用意したクエリ)メソッドを使って、
			//用意したSQLをDBに届けるためのPreparedStatement型インスタンスを作成
			PreparedStatement ps = conn.prepareStatement(sql);


			//PreparedStatement.executeQuery()メソッドでクエリを実行し、
			//ResultSet型インスタンス(変数rs)に結果が格納される
			//結果　　　　　　　実行
			ResultSet rs = ps.executeQuery();


			//rs.next()取得結果が存在するかどうかを表すbool値)で条件分岐や繰り返しを行い、
			//ResultSetから情報を引き出す
			//rsの中身を順番に取り出す
			while (rs.next()) {
				//                      DBのカラム
				String id = rs.getString("ID");
				String name = rs.getString("NAME");
				int age = rs.getInt("AGE");

				System.out.println("ID:" + id);
				System.out.println("名前:" + name);
				System.out.println("年齢:" + age);

			}
			// エラーをキャッチ
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			// DBMSへの接続があるなら
			if (conn != null) {
				try {
					// DBMSの接続を切断
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} // try
	}//main
}//class

