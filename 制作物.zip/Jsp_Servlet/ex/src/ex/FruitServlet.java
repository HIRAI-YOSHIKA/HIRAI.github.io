package ex;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/FruitServlet")
public class FruitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		int price = new java.util.Random().nextInt(1001) + 100;
		String[] names = {"バナナ", "リンゴ", "キウイ", "モモ", "ドラゴンフルーツ", "シャインマスカット", "ライチ"};
		int value = new java.util.Random().nextInt(7);



		/*インスタンス生成*/
		Fruit f = new Fruit(names[value], price);

		/*Fruit f = new Fruit("いちご", 700);*/

		/*アプリケーションスコープ(リクエストスコープからセッションスコープからアプリケーション変更)に格納*/
		//"fruit"に、いちご fruitに700
		ServletContext application  = this.getServletContext();
		application.setAttribute("fruit",f);


		/*フォワードする*/
		RequestDispatcher d = request.getRequestDispatcher("/WEB-INF/fruit.jsp");
		d.forward(request, response);


	}


}
