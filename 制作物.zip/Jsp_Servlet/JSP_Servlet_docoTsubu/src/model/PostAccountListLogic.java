package model;

import dao.AccountDAO;

//つぶやき投稿の処理のモデル

public class PostAccountListLogic {
	public void execute(String name, String text) {
		AccountDAO dao = new AccountDAO();
		dao.createTsubu(name, text);
	}
}
