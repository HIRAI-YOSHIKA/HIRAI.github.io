package model;

import java.io.Serializable;

public class Mutter implements Serializable {

	/*フィールド*/

	//IDを追加
	private int id;

	//ユーザー名
	private String userName;


	//つぶやき内容
	private String text;




	/*コンストラクタ*/

	public Mutter(int id,String userName, String text) {
		this.id = id;
		this.userName = userName;
		this.text = text;


	}

	/*つぶやいたときの引数のコントラスト*/
	public Mutter(String userName, String text) {
		this.userName = userName;
		this.text = text;

	}




	/*gette*/



	public String getUserName() {
		return userName;
	}


	public int getId() {
		return id;
	}


	public String getText() {
		return text;
	}




}
