package model;

public class AccountUser {
	/*ログインしているか確認するために使用*/

	int pass;

	String name;

	public AccountUser(int pass, String name) {
		this.pass = pass;
		this.name = name;
	}

	public int getPass() {
		return pass;
	}

	public String getName() {
		return name;
	}




}
