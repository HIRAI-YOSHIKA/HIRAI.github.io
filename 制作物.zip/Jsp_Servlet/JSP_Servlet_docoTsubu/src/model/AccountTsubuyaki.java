package model;

public class AccountTsubuyaki {



	//IDを追加
	private int ID;


	private int PASS;

	//ユーザー名
	private String NAME;


	//つぶやき内容
	private String TEXT;


	//追加 年齢
	private int AGE;

	// 追加 電話番号 後で数字に変える (Integr)
	private String TEL;




	/*コンストラクタ*/
	public AccountTsubuyaki() {

	}

	public AccountTsubuyaki(int ID,int PASS , String NAME, String TEXT,int AGE, String TEL) {
		this.ID = ID;
		this.NAME = NAME;
		this.PASS = PASS;
		this.TEXT = TEXT;
		this.AGE = AGE;
		this.TEL = TEL;

	}

	/*つぶやいたときの引数のコントラスト*/
	public AccountTsubuyaki(String NAME, String TEXT) {
		this.NAME = NAME;
		this.TEXT = TEXT;

	}




	/*gette*/


	public String getName() {
		return NAME;
	}


	public int getID() {
		return ID;
	}


	public String getText() {
		return TEXT;
	}


	public int getAge() {
		return AGE;
	}


	public String getTel() {
		return TEL;
	}

	public int getPASS() {
		return PASS;
	}







}
