package model;


		/*ログインパス*/
public class LoginLogic {
/*
	public boolean execute(Mutter mutter) {

		if (user.getPass().equals("1234")) {

			return true;
		}

		return false;

	}
*/
/*	public boolean execute(User user) {
		if (user.getPass().equals("1234")) {

			return true;
		}

		return false;
	}
*/
}
