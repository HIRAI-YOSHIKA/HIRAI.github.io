package model;

import java.util.List;

import dao.AccountDAO;
/*マイページで確認するよう*/
public class GetMyAccountInfo {
	public List<Account> execute() {
		AccountDAO dao = new AccountDAO();
		List<Account> accountList = dao.findAll();
		return accountList;
	}

}
