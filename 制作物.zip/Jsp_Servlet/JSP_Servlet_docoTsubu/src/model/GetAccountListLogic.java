package model;

import java.util.List;

import dao.AccountDAO;

//つぶやきの取得

public class GetAccountListLogic {
	public List<Account> execute() {
		AccountDAO dao = new AccountDAO();
		List<Account> accountList = dao.findAll();
		return accountList;

	}

}
