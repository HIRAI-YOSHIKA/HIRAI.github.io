package model;

import java.io.Serializable;

public class Account implements Serializable{

/*accountテーブルのレコードを表すクラス*/
	/*フィールド*/
	//ID
	private int ID;

	private int PASS;

	//ユーザー名
	private String NAME;

	//つぶやき内容
	private String TEXT;


	//年齢
	private int AGE;

	// 電話番号 後で数字に変える (Integr)
	private int TEL;




	/*コンストラクタ*/

	public Account() {
	//引数がないコンストラクターを用意する決まり事。ない場合siriaraizaburuが機能しない
	}

	//マイページで登録内容確認用
	public Account(int id,int pass , String name, String text,int age, int tel) {
		this.ID = id;
		this.NAME = name;
		this.PASS = pass;
		this.TEXT = text;
		this.AGE = age;
		this.TEL = tel;

	}

	/*つぶやき時*/
	public Account(String name, String text) {
		this.NAME = name;
		this.TEXT = text;

	}
	/*ログイン時*/
	public Account(int pass, String name) {
		this.NAME = name;
		this.PASS = pass;

	}

	/*重複不可用（既にDBに無いか確認時に使用）*/
	public Account(int pass, String name, int tel) {

		this.PASS = pass;
		this.NAME = name;
		this.TEL = tel;
	}

	/*新規登録*/
	public Account(int pass, String name, int age, int tel) {

		this.PASS = pass;
		this.NAME = name;
		this.AGE = age;
		this.TEL = tel;
	}





	/*gette*/



	public String getName() {
		return NAME;
	}


	public int getID() {
		return ID;
	}



	public int getAge() {
		return AGE;
	}


	public int getTel() {
		return TEL;
	}

	public int getPASS() {
		return PASS;
	}


}
