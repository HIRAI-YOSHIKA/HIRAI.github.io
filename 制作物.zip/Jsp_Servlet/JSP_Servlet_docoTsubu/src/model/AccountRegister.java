package model;

public class AccountRegister {
	/*フィールド*/



	//IDを追加
	private int ID;


	private int PASS;

	//ユーザー名
	private String NAME;



	//追加 年齢
	private int AGE;

	// 追加 電話番号 後で数字に変える (Integr)
	private int TEL;

	private String text;


	/*コンストラクタ*/
	public AccountRegister(){}

	public AccountRegister(int id,int pass , String name,int age, int tel) {
		this.ID = ID;
		this.PASS = PASS;
		this.NAME = NAME;
		this.AGE = AGE;
		this.TEL = TEL;
	}






	public AccountRegister(int id, int pass, String name, int age, int tel, String text) {
		this.ID = id;
		this.PASS = pass;
		this.NAME = name;
		this.AGE = age;
		this.TEL = tel;
		this.text = text;
	}

	/*gette*/


	public String getName() {
		return NAME;
	}


	public int getID() {
		return ID;
	}




	public int getAge() {
		return AGE;
	}


	public int getTel() {
		return TEL;
	}

	public int getPASS() {
		return PASS;
	}





}
