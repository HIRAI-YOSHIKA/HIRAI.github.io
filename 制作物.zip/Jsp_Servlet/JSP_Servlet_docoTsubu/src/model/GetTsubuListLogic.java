package model;

import java.util.List;

import dao.AccountDAO;

//つぶやき取得に関する処理(Accountクラス)

public class GetTsubuListLogic {
	public List<Account> execute() {
		AccountDAO dao = new AccountDAO();
		List<Account> accountTsubuList = dao.findTsubu();
		return accountTsubuList;
	}


}
