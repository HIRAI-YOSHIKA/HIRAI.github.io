package listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class Listener_docotsubu
 *
 */
@WebListener
public class Listener_docotsubu implements ServletContextListener {

    /**
     * Default constructor.
     */
    public Listener_docotsubu() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg)  {
         System.out.println("リスナーが終了しました。");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg)  {
         System.out.println("リスナーが始動しました。");
    }

}
