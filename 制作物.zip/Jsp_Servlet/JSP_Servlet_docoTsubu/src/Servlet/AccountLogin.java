package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AccountDAO;
import model.AccountUser;

/**
 * Servlet implementation class AccountLogin
 */
@WebServlet("/AccountLogin")
public class AccountLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/*ログイン情報なのでdoPost使用*/
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		/*リクエストパラメーターの取得*/
		//request.setCharacterEncoding("UTF-8");
		String pass = request.getParameter("PASS");
		String name = request.getParameter("NAME");


		//ユーザー
		/*テキストで受け取るのでinteger.parseInt()でString型からint型に直す。*/
		AccountUser User = new AccountUser(Integer.parseInt(pass), name);


		//DAO生成
		AccountDAO dao = new AccountDAO();

		/*ログイン処理*/
		List<model.Account> accountList = dao.findAccount();
		request.setAttribute("accountlList", accountList);

		/*ログインしているか確認*/
		HttpSession session = request.getSession();
		AccountUser loginUser = (AccountUser) session.getAttribute("loguinUser");

		/*ログイン成功時の処理*/
		if (loginUser == null) {
			response.sendRedirect("/docotsubu");
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/AcountMain.jsp");
			dispatcher.forward(request, response);
		}






		/*ログイン結果画面にフォワード(ログイン時に表示するところを呼び出し)*/
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/AccountResult.jsp");
		dispatcher.forward(request, response);



	}

}
