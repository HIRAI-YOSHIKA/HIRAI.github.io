/*package Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginLogic;
import model.User;



@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ログイン情報なのでdoPost使用
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		リクエストパラメーターの取得
		//request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");

		Userインスタンス生成（ユーザー情報）
		User user = new User(name, pass);


		ログイン処理
		LoginLogic loginLogic = new LoginLogic();
		boolean isLogin = loginLogic.execute( user);

		ログイン成功時の処理

		if (isLogin) {

			ユーザー情報をセッションに保存
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", user);

		}

		ログイン結果画面にフォワード(ログイン時に表示するところを呼び出し)
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/docotsubuLogin.jsp");
		dispatcher.forward(request, response);



	}

}
*/