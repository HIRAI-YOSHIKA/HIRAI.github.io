package Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AccountDAO;
import model.Account;
/*新規登録*/
/**
 * Servlet implementation class AccountRegister
 */
@WebServlet("/RegisterationAccount")
public class RegisterationAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");


		//値を受け取る(formでもらった値)
				String name = request.getParameter("NAME");
				String pass = request.getParameter("PASS");
				String age = request.getParameter("AGE");
				String tel = request.getParameter("TEL");

				/*重複不可*/


				System.out.println("値受け取り");

				/*DAOインスタンス*/
				AccountDAO dao = new AccountDAO();



				/*DAOのcreate()を呼び出しdao.create()の引数を使って値を受け渡し*/
				/*(boolean ansに)DBに送信できたか？のtrue または falseの結果を代入（成功したか失敗か分かるようにするため）*/
				boolean ans = dao.create(name, pass, age, tel);

				/*成功（true）失敗（false）の場合の分岐*/
				/*boolian型(真偽値)なのでtrueの場合直下の｛｝を実行
				falseの場合else {} を実行おこなうため比較を行う必要がない。すっきりjava(p111 下から7行目)*/


				System.out.println("DBに送信");

				if (ans) {
					System.out.println(ans);
					Account accountUser = new Account();

					/*フォワードする*/
					RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/RegisterationAccount.jsp");
					dispatcher.forward(request, response);
				} else {
					System.out.println("false");
					response.sendRedirect("/WEB-INF/jsp/Not_New_Account.jsp");

				}





	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);

	}

}
