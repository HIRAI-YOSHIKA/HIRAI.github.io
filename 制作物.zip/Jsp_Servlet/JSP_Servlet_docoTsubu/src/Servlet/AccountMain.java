package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Account;
import model.AccountUser;
import model.GetTsubuListLogic;
import model.PostAccountListLogic;
import model.User;


@WebServlet("/AccountMain")
public class AccountMain extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		/*つぶやきリストを取得して、リクエストスコープに保存*/
		GetTsubuListLogic getTsubuListLogic = new GetTsubuListLogic();
		List<Account> accountList = getTsubuListLogic.execute();
		request.setAttribute("accountList", accountList);


		/*ログインしているか確認するため
		セッションスコープからユーザー情報*/
		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");



		/*ログインしていないとき*/
		if (loginUser == null) {

			//リダイレクト
			response.sendRedirect("/docoTsubu/");

		} else {
			//ログイン済みの時


			//フォワードする（メインに）
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/AccountMain.jsp");
			dispatcher.forward(request, response);

		}

	} //doGet()


	protected void doPost(HttpServletRequest request, HttpServletResponse respomse) throws ServletException, IOException{

		//リクエストパラメーターの取得
		 request.setCharacterEncoding("UTF-8");
		 String name = request.getParameter("name");
		 String text = request.getParameter("text");


		 //入力値チェック
		 if (text != null && text.length() != 0) {


			 /*セッションスコープに保存されたユーザー情報を取得 アカウントがログインしているかを確かめるために行う*/
			 HttpSession session = request.getSession();
			 AccountUser loginUser = (AccountUser) session.getAttribute("loginUser");


			/*PostAccountクラス（dao.createTubu(name, text))*/
			 PostAccountListLogic postAccountListLogic = new PostAccountListLogic();
			 postAccountListLogic.execute(name, text);

		 } else {

			 /*エラーメッセージをリクエストスコープに保存*/
			 request.setAttribute("errorMsg", "つぶやきが入力されていません");

		 }
		/* つぶやきリストを取得して、リクエストスコープに保存*/

		/* GetTsubuListLogicクラス（dao.findTsubu()）*/
		 GetTsubuListLogic getAccountListLogic = new GetTsubuListLogic();
		 List<Account> accountList = getAccountListLogic.execute();
		 request.setAttribute("accountList", accountList);

		 /*メイン画面にフォワード*/
		 RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/AccountMain.jsp");
		 dispatcher.forward(request, respomse);

	}

}
