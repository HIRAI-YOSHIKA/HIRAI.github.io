package Servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AccountDAO;
import model.AccountRegister;

/**
 * Servlet implementation class AccountCompletion
 */
@WebServlet("/AccountCompletion")
public class AccountCompletion extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Integer.parseInt()に入れてint型にしID:に格納
		int id = Integer.parseInt( request.getParameter("ID"));
		int pass = Integer.parseInt(request.getParameter("PASS"));
		String name = request.getParameter("NAME");
		int age = Integer.parseInt(request.getParameter("AGE"));
		int tel = Integer.parseInt(request.getParameter("TEL"));

		//accountのインスタンスを生成する
		AccountRegister account = new AccountRegister(id, pass, name, age, tel);


		//入力された値をサーバーから呼び出し渡す。
		AccountDAO dao = new AccountDAO();




		RequestDispatcher dispatcher = request.getRequestDispatcher("/docoTsubu/WEB-INF/registerAccount.jsp");
		dispatcher.forward(request, response);

	}

}
