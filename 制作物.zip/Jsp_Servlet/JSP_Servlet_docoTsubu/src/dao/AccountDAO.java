package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Account;

public class AccountDAO {
	/*データベース接続に必要な情報*/
	String url = "jdbc:mysql://localhost/docotsubu_hirai?useUnicode=true&characterEncoding=utf8";
	String user = "root";
	String password = "root";

	/*すべてのアカウント情報取得*/
	public List<Account> findAll() {

		System.out.println("始まり");

		// returnするリストを用意
		List<Account> accountList = new ArrayList<>();

		Connection conn = null;

		/*データベースに接続*/
		try{
			System.out.println("try開始");
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url, user, password);

			/*SELECT文を用意(DBから最新情報取り出す)*/
			String sql = "SELECT ID , PASS,NAME ,TEXT ,AGE, TEL FROM ACCOUNT ORDER BY ID DESC";
			System.out.println("SELECT後");

			PreparedStatement ps = conn.prepareStatement(sql);

			/*SELECT分を実行し、結果取得*/
			ResultSet rs = ps.executeQuery();

			/*結果表に格納されたレコード内容を
			Accountインスタンスに入れ、
			ArryListインスタンスにAccountインスタンスを追加*/
			while (rs.next()) {
				int id = rs.getInt("ID");
				int pass = rs.getInt("PASS");
				String name = rs.getString("NAME");
				String text = rs.getString("TEXT");
				int age = rs.getInt("AGE");
				int tel = rs.getInt("TEL");

				/*レコード内容をAccountインスタンスに格納*/
			Account account = new Account(id , pass, name , text, age, tel);

			/*ArryListインスタンスにAccountインスタンスを追加*/
			accountList.add(account);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} // try

		return accountList;

	}//findAll


/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
/*重複不可用*/
	public List<Account> duplication() {
		/*returnのリスト用意*/
		List<Account> accountList = new ArrayList<>();

		Connection conn = null;

		/*データベースに接続*/
		try{
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url, user, password);

			/*SELECT文を用意(DBから情報取り出す)*/
			String sql = "SELECT PASS, NAME, TEL FROM ACCOUNT ORDER BY ID DESC";

			/*DBから取得した情報*/
			PreparedStatement ps = conn.prepareStatement(sql);

			/*SELECT分を実行し、結果取得*/
			ResultSet rs = ps.executeQuery();

			/*結果表に格納されたレコード内容を
			Accountインスタンスに入れ、
			ArryListインスタンスにAccountインスタンスを追加*/
			while (rs.next()) {
				int pass = rs.getInt("PASS");
				String name = rs.getString("NAME");
				int tel = rs.getInt("TEL");
				/*レコード内容をAccountインスタンスに格納*/
			Account account = new Account(pass, name, tel);

			/*ArryListインスタンスにAccountインスタンスを追加*/
			accountList.add(account);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} // try

			return null;
	}

/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
/*ログイン時に必要な情報DB取得*/
	public List<Account> findAccount() {

		// returnするリストを用意
		List<Account> accountList = new ArrayList<>();

		Connection conn = null;

		/*データベースに接続*/
		try{Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url, user, password);

			/*SELECT文を用意(DBから情報取り出す)*/
			String sql = "SELECT PASS, NAME FROM ACCOUNT ORDER BY ID DESC";

			/*DBから取得した情報*/
			PreparedStatement ps = conn.prepareStatement(sql);

			/*SELECT分を実行し、結果取得*/
			ResultSet rs = ps.executeQuery();

			/*結果表に格納されたレコード内容を
			Accountインスタンスに入れ、
			ArryListインスタンスにAccountインスタンスを追加*/
			while (rs.next()) {
				int pass = rs.getInt("PASS");
				String name = rs.getString("NAME");

				/*レコード内容をAccountインスタンスに格納*/
			Account account = new Account(pass, name);

			/*ArryListインスタンスにAccountインスタンスを追加*/
			accountList.add(account);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} // try

		return accountList;

	}//findAccount終わり

	/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/
	/*つぶやき時*/
	public List<Account> findTsubu() {
		// returnするリストを用意
		List<Account> accountList = new ArrayList<>();

		Connection conn = null;

		/*データベースに接続*/
		try{
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url, user, password);

			/*SELECT文を用意(DBから情報取り出す)*/
			String sql = "SELECT ID,NAME, TEXT FROM ACCOUNT ORDER BY ID DESC";

			/*DBから取得した情報*/
			PreparedStatement ps = conn.prepareStatement(sql);

			/*SELECT分を実行し、結果取得*/
			ResultSet rs = ps.executeQuery();

			/*結果表に格納されたレコード内容を
			Accountインスタンスに入れ、
			ArryListインスタンスにAccountインスタンスを追加*/
			while (rs.next()) {

				String name = rs.getString("NAME");
				String text = rs.getString("TEXT");

				/*レコード内容をAccountインスタンスに格納*/
				Account account = new Account(name, text);

				/*ArryListインスタンスにAccountインスタンスを追加*/
				accountList.add(account);
			}

			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
					e.printStackTrace();
				} finally {
					if (conn != null) {
						try {
							conn.close();
						} catch (SQLException e) {
								e.printStackTrace();
							}
					}
		} // try

		return accountList;

	} //findTsubu終わり


//■■■■■■■■■■■■■－－DBに情報を登録する－－■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■

	/*アカウント新規作成登録*/
	/*入力してもらった値を引数に入れる*/
	public boolean create(String pass, String name, String age, String tel) {

		Connection conn = null;

		try{
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url, user, password);

			//プレースホルダによるSQL分の組み立て
			//SQL文の中にクエスチョンマーク（？）の形でパラメータを埋め込んで仮のSQL文を作る
			//利点・・・SQL文の見易さ・不正な検索を防止
			String sql = "INSERT INTO account2(PASS, NAME, AGE, TEL) VALUES(?,?,?,?)";

			/*取得した値をサーバーに送る*/
			PreparedStatement ps = conn.prepareStatement(sql);

			//SQLの文にあった(？)の位置に値を入れる
			//第一引数・・・  (？)の場所   , 第二引数・・・値

			/*DBに渡す値をsetterの引数に入れる*/
			ps.setString(1, pass);
			ps.setString(2, name);
			ps.setString(3, age);
			ps.setString(4, tel);

			//SELECT文の際に使用したexecuteQuery()の戻り値は
			//検索の結果が格納されているResultSetオブジェクト
			//executeUpdate()の戻り値は更新した行数(int)
			//INSERT文，UPDATE文，DELETE文の際に使用
			int result = ps.executeUpdate();

			//１行更新できたら
			if(result == 1){
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();	//StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
		} catch (ClassNotFoundException e) {
			e.printStackTrace(); //StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace(); //StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
				}
			}
		} // try

		return false;

	}//create



/*■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■*/

	//つぶやいた情報をDBに送る
		public boolean createTsubu(String name, String text) {


			Connection conn = null;

			try{
				Class.forName("com.mysql.jdbc.Driver");

				conn = DriverManager.getConnection(url, user, password);

				String sql = "INSERT INTO account2(NAME, TEXT) VALUES(?,?)";

				/*取得した値をサーバーに送る*/
				PreparedStatement ps = conn.prepareStatement(sql);

				/*DBに渡す値をsetterの引数に入れる*/
				ps.setString(1, name);
				ps.setString(2, text);

				//executeUpdate()の戻り値は更新した行数(int)
				//INSERT文，UPDATE文，DELETE文の際に使用
				int result = ps.executeUpdate();

				//１行更新できたら
				if(result == 1){
					return true;
				}

			} catch (SQLException e) {
				e.printStackTrace();	//StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
			} catch (ClassNotFoundException e) {
				e.printStackTrace(); //StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
			} finally {
				if (conn != null) {
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace(); //StackTrace()エラーが起きた場合表示する（成功したか失敗か分かるようにするため）
					}
				}
			} // try

			return false;


		}






}//class



