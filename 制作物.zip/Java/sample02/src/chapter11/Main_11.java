package chapter11;

public class Main_11 {

	public static void main(String[] args) {
		//Character c = new Character();
		Dancer d = new Dancer();
		Matango m = new Matango();

		d.attack(m);
		d.dance();
	}

}
