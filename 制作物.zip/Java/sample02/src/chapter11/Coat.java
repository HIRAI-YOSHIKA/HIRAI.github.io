package chapter11;

public class Coat {

}
