package chapter11;

public interface Thing {

	double getWeight();					//public  abstract 省略！
	void setWeight(double Weight);		//13章で分かる！

}
