package chapter11;

public class Book  extends TangibleAsset {	//extends で違う部分だけ記述する

	String isbn;

	public Book(String name, int price, String color, String isbn) {		//isbn以外は無い
		super(name, price, color);											//のでTangibleAsset(親)から呼びだし依頼をする
		this.isbn = isbn;
	}

	public String getisbn() {return this.isbn;}

}
