package chapter11;

public class Shirt {

}
