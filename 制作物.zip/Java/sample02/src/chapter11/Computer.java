package chapter11;

public class Computer extends TangibleAsset{
	String name;
	int price;
	String color;
	String makerName;

	public Computer(String name, int price, String color, String makerName) {
		super(name, price, color);												//superで親から呼び出し依頼かける
		this.makerName = makerName;

	}
		public String getmakerName() {return this.makerName;}

}
