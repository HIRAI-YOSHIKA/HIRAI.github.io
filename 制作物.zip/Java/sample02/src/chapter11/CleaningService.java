package chapter11;

public interface CleaningService {
	Shirt washShirt(Shirt s);
	Towl washTowl(Towl t);
	Coat washCoat(Coat c);

}

