package chapter11;

public interface Creature {
	void run();				//public abstractを省略できる

}
