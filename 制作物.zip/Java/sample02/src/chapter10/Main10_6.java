package chapter10;

public class Main10_6 {

	public static void main(String[] args) {

		Hero h = new Hero();

		h.run();


		SuperHero sh = new SuperHero();

		sh.run();
		//sh.attack(Matango m);




	}

}
