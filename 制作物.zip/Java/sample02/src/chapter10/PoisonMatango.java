package chapter10;

public class PoisonMatango extends Matango {

	int attackCount= 5;

	//--------フィールド------------------

	public PoisonMatango(char suffux) {
		super(suffux);


	}
	public void attack(Hero h) { //メソッドをつくる

		super.attack(h);		//呼び出す1つ内側の攻撃

		if (attackCount > 0) {		//1以上なら
			System.out.println("更に毒の胞子をバラまいた！");

			int damage = h.hp / 5;//ヒーローの5分の１体力の値を変数に代入

			h.hp -= damage;			//ヒーローの体力から減らす

			System.out.println(damage + "ポイントのダメージ！");

			attackCount--;			//カウント減らす
		}

	}


}
