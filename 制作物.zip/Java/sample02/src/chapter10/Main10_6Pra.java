package chapter10;

public class Main10_6Pra {

	public static void main(String[] args) {
		PoisonMatango pm = new PoisonMatango('A');

		Hero h = new Hero();

		pm.attack(h);


	}

}
