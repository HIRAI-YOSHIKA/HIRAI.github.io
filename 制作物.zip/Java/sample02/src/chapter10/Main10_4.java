package chapter10;

public class Main10_4 {

	public static void main(String[] args) {
		//勇者を生成
		//Hero h = new Hero();


		SuperHero sh = new SuperHero();

		sh.run();


	}

}
