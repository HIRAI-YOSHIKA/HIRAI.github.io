package chapter10;

public class SuperHero extends Hero {

	boolean flying; //新規追加フィールド



	public void fly() {			//新規追加メソッド
		this.flying = true;
		System.out.println("飛び上がった！");
	}
	//着地する
	public void land() {			//新規追加メソッド
		this.flying = false;
		System.out.println("着地した！");
	}
	//逃げる
	public void run() {
		System.out.println(this.name + "撤退した"); //子クラスで再定義。オーバーライド
	}


	//戦う

		public void attack(Matango m) {
			System.out.println(this.name + "の攻撃");
			m.hp -= 5;
			System.out.println("5ポイントのダメージを与えた!");

		}
		public SuperHero() {
			System.out.println("SuperHeroのコンストラクタが動作");
		}

}
