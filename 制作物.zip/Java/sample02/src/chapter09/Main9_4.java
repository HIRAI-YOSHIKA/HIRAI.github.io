package chapter09;

public class Main9_4 {

	public static void main(String[] args) {

		Sword s = new Sword();
		s.name = "炎の剣";
		s.damage = 10;

		Hero h = new Hero();
		h.name = "ミナト";
		h.hp = 100;
		h.sword = s;

		/*h.sit(5);
		h.slip();
		h.sit(25);
		h.run();*/


		System.out.println("現在の武器は" + h.sword.name);

	}

}
