package chapter09;

public class Main9_11 {

	public static void main(String[] args){
		Hero h = new Hero("ミナト");



		System.out.println(h.hp);
		System.out.println(h.name);
	}

}
