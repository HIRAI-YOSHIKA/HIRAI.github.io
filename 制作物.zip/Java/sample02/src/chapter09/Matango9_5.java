package chapter09;

public class Matango9_5 {
	int hp;
	int level = 10;

	char suffux;

	/*public void slip() {
		this.hp -= 7;
		System.out.println(m1.suffux + "は眠った。ダメージ7を受けた");
	}*/


	public void run() {
		System.out.println("お化けキノコ" + this.suffux + "は、逃げ出した");
	}

}
