package chapter09;

public class Thief {

	String name;
	int hp;
	int mp;

	public Thief(String name, int hp, int mp) {
		this.name = name;
		this.hp = hp;
		this.mp = mp;
	}
	public Thief(String name, int hp) {
		this(name, hp, 5);				//同一クラス内の別コントラストの呼び出しをJVMに依頼

	}
	public Thief(String name) {			//同一クラス内の別のコントラストの呼び出し依頼
		this(name, 40);
	}

}

