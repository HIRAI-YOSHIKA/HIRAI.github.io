package chapter09;

public class Sword {
	String name;
	int damage;

}
