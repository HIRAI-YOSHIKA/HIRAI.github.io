package chapter13;

public class Main {

	public static void main(String[] args) {
		Wizard w = new Wizard();
		w.setName("");
		//w.setPower(0);


		Wizard wi = new Wizard();
		wi.setName(null);
		wi.setHp(-100);
		wi.setMp(-10);
		wi.setWand(null);

	}

}
