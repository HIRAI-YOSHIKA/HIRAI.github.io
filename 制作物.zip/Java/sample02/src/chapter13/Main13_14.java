package chapter13;

public class Main13_14 {

	public static void main(String[] args) {
		Hero h = new Hero();
		h.setName("");

		/*h.setName("ミナト");
		System.out.println(h.getName());*/
	}

}
