package chapter13;

public class Hero {

	private String name;


	private int hp; //制限をかけprivateをつける。

	private Sword sword;		//番地（アドレス）

	//------------------------ フィールド ----------------------------------------------------


	//getNameメソッド フィールドはprivateで制限されているメッソドを経由して中を見る。



	public String getName() {
		return this.name;
	}


	public int getHp() {
		return hp;
	}


	public void setHp(int hp) {
		this.hp = hp;
	}


	public Sword getSword() {
		return sword;
	}


	public void setSword(Sword sword) {
		this.sword = sword;
	}


	public void setName(String name) {

		//nullだと実行中断
		if (name == null) {
			throw new IllegalArgumentException("名前がnullである。処理を中断。");

		}

		//名前が1以下なら処理を中断。
		if (name.length() <= 1) {
			throw new IllegalArgumentException("名前が短すぎる。処理を中断。");

		}
		//8文字以上なら処理を中断。
		if (name.length() >=8) {
			throw new IllegalArgumentException("名前が長すぎる。処理を中断。");
		}
		this.name = name;
	}


	public void bye() {
		System.out.println("勇者は別れを告げた");

	}	//ここまでがbyeメソッド

									//メソッドは基本はpublicをつける
	private void die() {			//制限をかけprivateをつける。メソッドにprivateを付ける場合は理由があるので注記書きする。
		System.out.println(this.name + "は死んでしまいました");
		System.out.println("GAME OVERです。");
	}	//ここまでがdieメソッド


	private void sleep() {			//制限をかけprivateをつける。
		this.hp = 100;
		System.out.println(this.name + "は眠って回復した！");
	}	//ここまでがsleepメソッド


	public void attack(Matango m) {
		System.out.println(this.name + "は攻撃した！");
		System.out.println("お化けキノコ" + m.suffux + "から2ポイントの反撃を受けた");

		this.hp -= 2;
		if (this.hp <= 0) {
			this.die();
		}	//ここまでがattackメソッド

	}




	//public void



	public Hero(String name) {
		this.hp = 100;
		this.name = name;
	}
	public Hero() {
		/*this.hp = 100;
		this.name = "ダミー";*/

		this("ダミー");


	}


	/*	public void sleep() {
			this.hp = 100;

			System.out.println(this.name + "は、眠って回復した！");

		}
		public void sit (int sec) {
			this.hp += sec;
			System.out.println(this.name + "は、" + sec + "秒座った");
			System.out.println("HPが" + sec + "ポイント回復した");
		}
		public void slip() {
			this.hp -= 5;
			System.out.println(this.name + "は、転んだ！");

			System.out.println("5のダメージ");


		}
		public void run() {
			System.out.println(this.name + "は逃げ出した！");
			System.out.println("GAMEOVER");
			System.out.println("最終HPは" + this.hp + "でした");

		}*/




}
