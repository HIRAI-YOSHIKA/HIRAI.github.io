package chapter13;

public class Sword {
	String name;
	int damage;

}
