package chapter08;

public class Code8_16 {

	public static void main(String[] args) {
		Hero h = new Hero();
		h.name = "ミナト";
		h.hp = 100;

		Matango m1 = new Matango();
		m1.hp = 50;
		m1.suffux = 'A';

		Matango m2 = new Matango();
		m2.hp = 48;
		m2.suffux = 'B';

		h.slip();
		//m1.slip();
		m1.run();
		m2.run();
		h.run();



	}

}
