package chapter08;

public class Cleric {
	Cleric c = new Cleric();
	String name;

	int hp;
	final int MAX_HP = 50;

	int mp;
	final int MAX_MP = 10;

	//フィールド

	public void selfAid() {

		System.out.println(this.name + "はセルフエイドを唱えた！");

		this.hp = this.MAX_HP;

		this.mp -= 5;
		System.out.println(this.mp + "HPが最大まで回復した");

	}
	public int pray(int sec) {		//祈った秒数 sec

		System.out.println();


		int cure = new java.util.Random().nextInt(3) + sec; //補正



		int recovery = 0;

		if (this.mp < this.MAX_MP) {

			recovery = this.mp + cure;
			System.out.println(recovery + "回復した");

		} else {
			System.out.println(this.MAX_MP);
		}


		return recovery;
	}
}

