package chapter12;

public class Thief extends Character {

	@Override
	public void attack(Monster m) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
