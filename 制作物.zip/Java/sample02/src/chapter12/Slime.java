package chapter12;

public class Slime extends Monster {
	public void run() {
		System.out.println("スライムはサササっと逃げ出した");
	}

}
