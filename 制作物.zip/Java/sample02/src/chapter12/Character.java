package chapter12;

public abstract class Character {
	String name;
	int hp;

	public void run() {}

	public  void attack(Monster m) {				//モンスター攻撃用
		System.out.println(this.name + "の攻撃!");
		System.out.println("敵に10ポイントのダメージを与えた！");

		m.hp -= 10;
	}


}
