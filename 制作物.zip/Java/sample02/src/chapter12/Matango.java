package chapter12;

public class Matango extends Monster{		//Monsterクラスを継承

	//int hp = 50;
	//int level = 10;

	char suffux;
	public Matango(char suffux) {
		this.suffux = suffux;
	}
	public Matango() {
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public void attack(Hero h){
		System.out.println("キノコ" + this.suffux + "の攻撃");
		System.out.println("10のダメージ");
		h.hp -= 10;
	}

		/*public void slip() {
			this.hp -= 7;
			System.out.println(m1.suffux + "は眠った。ダメージ7を受けた");
		}*/


	/*public void run() {
			System.out.println("お化けキノコ" + this.suffux + "は、逃げ出した");
	}*/


}
