package chapter12;

public class Main12_5 {

	public static void main(String[] args) {
		Slime s = new Slime();
		Monster m = new Slime();
		s.run();
		m.run();

	}


}
