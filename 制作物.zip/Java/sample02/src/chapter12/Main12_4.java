package chapter12;

public class Main12_4 {

	public static void main(String[] args) {
		Wizard w = new Wizard();

		Character c = w;

		Matango m = new Matango();

		c.name = "アサカ";
		c.attack(m);
		//c.fireball(m);


		if (c instanceof Wizard) {		//キャスト演算子を使う（ダウンキャスト）
			w = (Wizard)c;				//Wizardとみなすように命令(代入しなおし)
			w.fireball(m);
		}


	}

}
