package chapter12;

public abstract class Monster {

	int hp;

	public void run() {
		System.out.println("モンスターは逃げ出した");
	}
}
