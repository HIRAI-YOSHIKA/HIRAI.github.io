package chapter12;

public class Main12_6 {

	public static void main(String[] args) {
		Hero h1 = new Hero();
		Hero h2 = new Hero();
		Thief t1 = new Thief();
		Wizard w1 = new Wizard();
		Wizard w2 = new Wizard();

		//冒険開始
		//まず宿屋に泊まる

		//各50体力回復
		h1.hp += 50;
		h2.hp += 50;
		t1.hp += 50;
		w1.hp += 50;
		w2.hp += 50;

		System.out.println(h1.hp);
		System.out.println(h2.hp);
		System.out.println(t1.hp);
		System.out.println(w1.hp);
		System.out.println(w2.hp);
	}

}
