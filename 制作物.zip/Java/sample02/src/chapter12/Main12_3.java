package chapter12;

public class Main12_3 {

	public static void main(String[] args) {
		Wizard w = new Wizard();

		Matango m = new Matango();
		w.name = "アサカ";
		w.attack(m);
		w.fireball(m);

	}

}
