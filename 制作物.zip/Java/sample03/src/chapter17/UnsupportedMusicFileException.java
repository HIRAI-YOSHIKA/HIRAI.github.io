package chapter17;

public class UnsupportedMusicFileException  extends Exception {

	public UnsupportedMusicFileException(String msg) {
		super (msg);
	}
}
