package chapter17;

import java.io.FileWriter;
import java.io.IOException;

public class Main17_1_2 {

	public static void main(String[] args) {


		try {
			FileWriter fw = new FileWriter("data.taxt");


		} catch (IOException e) {
			System.out.println("エラーが発生しました");

		}

	}

}
