package chapter17;

public class Main17_11 {

	public static void main(String[] args) {

		Person p = new Person();

		p.setAge(-128);

	}

}
