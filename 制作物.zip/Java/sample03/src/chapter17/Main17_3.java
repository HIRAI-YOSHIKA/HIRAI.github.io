package chapter17;

public class Main17_3 {

	public static void main(String[] args) {

		try {
			//文字列から数字へ変換するInteger.parseInt()を使用
			int i = Integer.parseInt("三");

		} catch (NumberFormatException e) {

			System.out.println("NumberFormatException 例外を catch しました");

		}

	}

}
