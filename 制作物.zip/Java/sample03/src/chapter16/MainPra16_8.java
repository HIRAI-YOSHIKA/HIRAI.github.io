package chapter16;

import java.util.HashMap;
import java.util.Map;

public class MainPra16_8 {

	public static void main(String[] args) {
		Hero h1 = new Hero("斎藤");
		Hero h2 = new Hero("鈴木");

		//HashMap
		Map<Hero, Integer> heros = new HashMap<>();

		heros.put(h1, 3);
		heros.put(h2, 7);

		for (Hero h : heros.keySet()) {
			System.out.println(h.getName());
		}

	}

}
