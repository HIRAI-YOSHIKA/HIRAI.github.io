package chapter16;

import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

public class Main16_Iterator {

	public static void main(String[] args) {
		List<String> fruits = new ArrayList<String>();
		Collections.addAll(fruits, "れもん", "りんご", "ばなな", "カカオ", "ブルーベリー", "りんご");

		try {
			for (String fruitName : fruits) {

				if (fruitName.equals("りんご")) {

					fruits.remove(fruitName);

				}

			}
		} catch (ConcurrentModificationException e) {
			System.out.println("*拡張for文ではRemoveできません");
			e.printStackTrace();
		}

		for(Iterator<String> iterator = fruits.iterator();iterator.hasNext();){
			String fruitName = iterator.next();
			if (fruitName.equals("りんご")) {
				iterator.remove();

			}
		}
		System.out.println(fruits);
	}

}
