package chapter16;

import java.util.HashSet;
import java.util.Set;

public class Main16_3 {

	public static void main(String[] args) {

		Set<String> colors = new HashSet<String>();

		colors.add("赤");
		colors.add("青");
		colors.add("黄");
		colors.add("赤");		//重複して格納されようとしても無視される

		System.out.println("色は" + colors.size() + "種類");

		for (String s : colors) {
			System.out.print(s + "→");				//格納された順番ではない
		}


	}

}
