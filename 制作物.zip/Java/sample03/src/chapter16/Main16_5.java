package chapter16;

import java.util.Set;
import java.util.TreeSet;

public class Main16_5 {

	public static void main(String[] args) {

		Set<String>words = new TreeSet<String>();

		words.add("dog");
		words.add("cat");
		words.add("wolf");
		words.add("panda");
		for (String s : words) {
			System.out.print(s + "→");
		}
		System.out.println("");

		Set<String> colors = new TreeSet<String>();

		colors.add("赤");
		colors.add("青");
		colors.add("黄");


		for (String s : colors) {
			System.out.print(s + "→");				//格納された順番ではない
		}



	}

}
