package chapter15;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Main_Pra15_4 {

	public static void main(String[] args)  {


		Date now = new Date();

		Calendar calendar = Calendar.getInstance();

		calendar.setTime(now);

		int day = calendar.get(Calendar.DAY_OF_MONTH);

		day += 100;

		calendar.set(Calendar.DAY_OF_MONTH, day);

		Date future = calendar.getTime();


		SimpleDateFormat fmt = new SimpleDateFormat("西暦yyyy年MM月dd日");

		System.out.println(fmt.format(future));






		/*LocalDate ldatep = ldate.plusDays(100);
		String str = ldatep.format(fmt);
		System.out.println("100日後は" + fmt);
		*/

	}

}
