package chapter15;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Main15_16 {

	public static void main(String[] args) {

		//文字列からLocalDateを生成

		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd");

		LocalDate ldate = LocalDate.parse("2020/09/22", fmt);


		LocalDate ldatep = ldate.plusDays(1000);

		String str = ldatep.format(fmt);

		//1000日後を計算する

		System.out.println("1000日後は" + str);


		//現在日付との比較
		LocalDate now = LocalDate.now();

		if (now.isAfter(ldatep)) {		//isAfterはboolean型のメソッド
			System.out.println("1000日後は過去日付です");
		}
	}

}
