package chapter15;

public class Main15_3 {

	public static void main(String[] args) {

		String s1 = "Java programming";

		// substring 指定位置から始まる文字列を任意の長さだけ切り出す
		System.out.println("文字列s1の四文字目以降は" + s1.substring(3));

		// substring 指定位置から始まる文字列を任意の長さだけ切り出す(3以上8未満なので3から7文字目)
		System.out.println("文字列s1の4～8文字目は" + s1.substring(3, 8));
	}

}
