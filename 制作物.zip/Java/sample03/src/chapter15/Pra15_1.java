package chapter15;

public class Pra15_1 {

	public static void main(String[] args) {

		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < 100; i++) {
			sb.append(i + 1);
			sb.append(",");

		}

		String s = sb.toString();
		String[] a = s.split(",");

		for (String num : a) {
			System.out.println(num);
		}

	}

}
