package chapter15;

import java.text.SimpleDateFormat;		//先にインスタンスを生成する
import java.util.Date;

public class Main15_13 {

	public static void main(String[] args) throws Exception {				//throws Exceptionつけ忘れないようにする

		SimpleDateFormat f = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		//文字列(String)からDateインスタンス（静的インスタンス）を生成
		Date d = f.parse("2020/09/22 01:23:45");		//throws Exceptionを付けないと赤波線がでるので注意

		System.out.println(d);

		//Dateインスタンスから文字列(String)を生成
		Date now = new Date();

		String s = f.format(now);

		System.out.println("現在は" + s + "です");

	}

}
