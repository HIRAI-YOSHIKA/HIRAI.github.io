package chapter15;

public class Main15_4 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < 1000; i++) {

			sb.append("Java");

		}
		//toString()で出力させる
		String s = sb.toString();

		System.out.println(s);


	}

}
