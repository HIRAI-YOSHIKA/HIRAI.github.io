package chapter14;

public class Main_14_4 {

	public static void main(String[] args) {
		Hero h = new Hero();
		h.name ="ミナト";
		h.hp = 100;
		System.out.println(h.toString());
	}

}
