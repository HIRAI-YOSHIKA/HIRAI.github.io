package chapter14;

public class Main14_1 {

	public static void main(String[] args) {

		Empty e = new Empty();

		String s = e.toString();

		System.out.println(s);

	}

}
