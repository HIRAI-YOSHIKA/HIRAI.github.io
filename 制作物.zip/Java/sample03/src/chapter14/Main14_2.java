package chapter14;

public class Main14_2 {

	public static void main(String[] args) {
		Object o1 = new Empty();
		Object o2 = new Hero();
		Object o3 = "こんにちは";
	}

}
