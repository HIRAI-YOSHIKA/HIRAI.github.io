package chapter14;

public class Main14_3 {


	public static void main(String[] args) {
		Object o3 = "こんにちは";
		printAnything(o3);

		//直接基本データ型を格納できないが
		//ラッパークラスに変換して格納している

	}

	public static void printAnything (Object o) {
		System.out.println(o.toString());
	}



}
