package chapter14;

public class Empty {

}
