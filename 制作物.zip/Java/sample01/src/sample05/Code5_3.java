package sample05;

public class Code5_3 {

	public static void methodA() {
		System.out.println("methodA");
		methodB(); 						//メソッドB呼び出し
	}

	public static void methodB(){

		System.out.println("methodB");		//

	}

	public static void main(String[] args) {
	methodA();								//メソッドA呼び出し
	}

}
