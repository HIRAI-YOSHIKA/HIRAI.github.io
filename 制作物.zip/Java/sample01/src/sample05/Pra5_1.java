package sample05;

public class Pra5_1 {



	public static void main(String[] args) {

		introduceOneself();

	}


	public static void introduceOneself() {
		String name = "南畑";
		int age = 27;
		double  heighe = 168.0;
		char zodiac = '猿';




		System.out.println("私の名前は" + name + "です");
		System.out.println("年齢は" + age + "です");
		System.out.println("身長は" + heighe +"です");
		System.out.println("干支は" + zodiac + "です");

		System.out.println();
	}

}
