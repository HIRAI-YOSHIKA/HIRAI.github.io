package sample05;

public class Code5_2 {

	public static void main(String[] args) {

		System.out.println("メソッドを呼び出します");

		hello();
		//hello(); コントロールキー＋スペースで予測変換可
		System.out.println("メソッドを呼び出し終わりました");
	}

	/*
	 * hello()
	 * 引数：なし
	 *戻り値：なし
	 * */

	public static void hello() {

		System.out.println("湊さん、こんにちは");
	} //hello() 終わり

}
