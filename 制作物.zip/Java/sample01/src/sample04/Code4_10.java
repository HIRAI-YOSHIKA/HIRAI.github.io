package sample04;

public class Code4_10 {

	public static void main(String[] args) {
		//int[]	型の配列変数を宣言
		//同時に初期化も実地
		int[] scores = {20, 30, 40, 50, 80};

		 //合計値も格納するint型変数sumを宣言
		int sum = 0;

		//for
		 for(int i = 0; i < scores.length; i++) {
			 sum += scores[i];

		 }
		 int avg = sum / scores.length;
		 System.out.println("合計点" + sum);

		 System.out.println("平均点" + avg);
	}

}
