package sample04;

public class code4_4 {

	public static void main(String[] args) {
		int [] scores = new int[10];
		int num = scores.length;

		System.out.println("要素の数:" + num);
	}

}
