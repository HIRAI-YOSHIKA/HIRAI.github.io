package sample04;

public class Code4_8 {

	public static void main(String[] args) {
		int [] scores = {20, 30,40, 50, 80};
		//合計点の算出 ０～4(インディント)なのでエラーがでる
		int sum = scores[1] + scores[2] + scores[3] + scores[4] +scores[5];

		//平均値の算出
		int avg = sum / scores.length;

		//合計と平均の表示
		System.out.println("合計点" + sum);
		System.out.println("平均点" + avg);
	}

}
