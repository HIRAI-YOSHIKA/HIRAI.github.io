package sample04;

public class Code4_7 {


	public static void main(String[] args) {
		int[] scores = new int[5];
		System.out.println(scores[0]);
		
	}

}
