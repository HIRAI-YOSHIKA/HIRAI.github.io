package sample04;

public class Q4_14 {

	public static void main(String[] args) {
		int[] scores = {20, 30, 40, 50, 80};
		for (int value : scores) {
			System.out.println(value);
		}

	}

}
