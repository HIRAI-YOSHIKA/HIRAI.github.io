package sample04;

public class Code4_3 {

	public static void main(String[] args) {
		int [] scores = new int[5];

	}



}
