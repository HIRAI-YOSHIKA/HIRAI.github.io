package sample04;

public class Code4_2 {

	public static void main(String[] args) {
		int [] scores;
		scores = new int [5];

	}

}
