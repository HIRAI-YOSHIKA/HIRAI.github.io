package sample04;

public class Pra4_4 {

	public static void main(String[] args) {
		int[] numbers = {3, 4, 9,};
		System.out.println("画面に一桁の数字を入力してください");

		int input = new java.util.Scanner(System.in).nextInt();

		for(int x : numbers) {


			if(x == input) {
				System.out.println("当たり");
				break;
			} else if(x != ((numbers.length - 1))) { // numbers.length最後の数字出るようにできる 0～2なのでー1にする

			}
		}  System.out.println("はずれ");

	}
}

