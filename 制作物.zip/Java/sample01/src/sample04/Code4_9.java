package sample04;

public class Code4_9 {

	public static void main(String[] args) {
		int[] scores = {20, 30, 40, 50, 80};

		//ループのたび値が０～４で変化
		for(int i = 0; i < scores.length; i++) {
			System.out.println(scores[i]);
		}


	}

}
