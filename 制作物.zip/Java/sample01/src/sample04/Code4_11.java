package sample04;

public class Code4_11 {

	public static void main(String[] args) {
		//int[]型の配列数scoresを宣言
		//同時に初期化も実地
		int[] scores = {20, 30, 40, 50, 80};

		//カウント数を格納するintが多数countを宣言
		int count = 0;

		//for文で要素を一個ずつ取り出す
		for(int i = 0; i < scores.length; i++) {

			//もしscores[i]
			if(scores[i] >= 50) {
				count++;
			}

		}
		System.out.println("５０点以上の科目は：" + count);
	}

}
