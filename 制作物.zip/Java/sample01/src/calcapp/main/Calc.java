package calcapp.main;

import calcapp.logics.CalcLogic;

public class Calc {

	public static void main(String[] args) {
		int a = 10;
		int b = 2;

		int totale = CalcLogic.tasu(a, b);
		int delta = CalcLogic.hiku(a, b);

		System.out.println("足すと" + totale + "引くと" + delta);

	}




}
