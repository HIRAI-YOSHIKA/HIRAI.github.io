
public class Code2_9 {

	public static void main(String[] args) {

//		文字列変数msgを宣言
//		msgに"私の年齢は23"

		String msg = "私の年齢は" + 23;


		System.out.println(msg);



	}

}
