package sample06;

public class Code6_10 {

	public static void main(String[] args) {
		int[] heights = {172, 149, 152, 191, 155};
		java.util.Arrays.sort(heights);

		for (int h : heights) {		//並び替えのロジック
			System.out.println(h);
		}
	}

}
