package samole03;

public class Pra3_6 {

	public static void main(String[] args) {
		System.out.println("【数あてゲーム】");

		//System.out.println(ans); 乱数を確認できる出力の中を乱数の変数を入れる
				//乱数がわからないと大変なのでしらべれる

		int ans = new java.util.Random().nextInt(10);


		//5回繰り返す文
		for (int i = 0; i < 5; i++) {

			System.out.println("0～9の数字を入れてください");

			int num = new java.util.Scanner(System.in).nextInt();

			if (num == ans) {
				System.out.println("当たり！");

				break;
			 } else {
				 System.out.println("違います");

			 }

		}
				System.out.println("ゲームを終了します"); // ゲームを終了しますは外に書く


	}

}
