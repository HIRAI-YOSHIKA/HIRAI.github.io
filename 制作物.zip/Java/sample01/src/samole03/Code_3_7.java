package samole03;

public class Code_3_7 {

	public static void main(String[] args) {


		//x++がないとずっと繰り返す。
		for (int x = 0; x < 10; x++) {
			System.out.println("おはようございます");
		}

	}

}
