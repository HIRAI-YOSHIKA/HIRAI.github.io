package samole03;

public class Code3_8 {

	public static void main(String[] args) {
		for (int i = 0; i < 3; i++) {
			System.out.print("現在" + (i + 1) + "周回→");
		}
	}

}
