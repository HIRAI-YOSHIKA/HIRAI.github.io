package samole03;

public class Code3__4 {

	public static void main(String[] args) {

		System.out.println( "あなたの運勢占います");

		//int型の変数fortuneを宣言し、
		//0～3の乱数を生成して
		int fortune = new java.util.Random().nextInt(4) + 1;
		if (fortune == 1) {
			System.out.println("大吉");
		} else if (fortune == 2) {
			System.out.println("中吉;");
		} else if (fortune == 3) {
			System.out.println("吉");
		} else {
			System.out.println("凶");



		}

	}

}
