package samole03;

public class Code3_2 {

	public static void main(String[] args) {

		boolean doorClose = true;

		while (doorClose == true) {
			System.out.println("ノックする");
			System.out.println("1分待つ");
		}



	}

}
