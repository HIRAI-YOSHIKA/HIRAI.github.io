package samole03;

public class Code3_9 {

	public static void main(String[] args) {
		for (int i = 1; i < 10; i++){

		  for(int j = 1; j < 10; j++){
			if (i * j < 10) { //
				System.out.print(" ");
			}
			System.out.print(i * j);     //掛け算の結果を出力する


			System.out.print(" "); 		 // 空白を入力する

		}
		System.out.println("");     	//改行を出力する


		}
	}

}
