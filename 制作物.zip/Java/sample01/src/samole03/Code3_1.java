package samole03;

public class Code3_1 {

	public static void main(String[] args) {
		//boolean型を宣言する
		boolean tenki = true;

		//tenkiの中身がtrueか判断する
 if (tenki == true) {      //もしtrueなら
	 System.out.println("洗濯します");
	 System.out.println("散歩に行きます");
 } else {
	 System.out.println("DVDをみます");
 }


	}

}
