package samole03;

public class Code3_7 {

	public static void main(String[] args) {

		for(int i = 0; i < 10; i++) {
			System.out.println("こんにちは");

		}


	}

}
