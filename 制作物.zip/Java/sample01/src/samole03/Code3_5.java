package samole03;

public class Code3_5 {

	public static void main(String[] args) {

		System.out.println("あなたの運勢占います");

		int foutune = 1;

		switch(foutune) {
		case 1:

		System.out.println("大吉");


		case 2:
		System.out.println("中吉");
		break;

		case 3:

		System.out.println("吉");
		break;

		default:
	    System.out.println("凶");


		}



	}

}
