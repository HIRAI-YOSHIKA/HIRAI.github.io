package samole03;

public class Pla_3 {

	public static void main(String[] args) {
		int isHungry = 1;
		 String food = "寿司";

		 System.out.println("こんにちは");

		 if (isHungry == 0) {
			System.out.println("お腹がいっぱいです");

		 } else {
			 System.out.println("腹ぺこです");

		 }

		 if(isHungry != 0) {

			 System.out.println(food + "をいただきます");
		 }

		 System.out.println("ごちそうさまでした");
	}

}
