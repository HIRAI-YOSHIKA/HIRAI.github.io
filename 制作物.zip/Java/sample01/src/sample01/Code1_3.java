package sample01;

public class Code1_3 {

	public static void main(String[] args) {
		//int型の変数ageを宣言して、20を代入
	    int age = 20;
	    
	    //変数ageを使って表示
		System.out.println("私の年齢は " + age);
		
		//ageに31を代入
		age = 31;
		
		//再度変数ageを使って表示
		System.out.println("…いや、本当の年齢は" + age);
		


	}

}
