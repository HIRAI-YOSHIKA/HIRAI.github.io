package sample01;

public class Code1_2 {

	//mainメソッドの開始
	public static void main(String[] args) {
	//"age"という名前の変数を宣言する
		int age;
	//"age"	という変巣に30を代入する
		age = 30;
	//"age"の中身を表示する
		System.out.println(age);
    //mainメソッドはここまで

	}

}
