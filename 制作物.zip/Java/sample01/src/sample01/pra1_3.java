package sample01;

public class pra1_3 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
