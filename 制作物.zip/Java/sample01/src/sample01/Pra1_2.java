package sample01;

public class Pra1_2 {

	public static void main(String[] args) {

		int a =3;
        int b = 5;
        // 変数の初期化

	    int c = a * b;
	    //計算の文、掛け算

	    System.out.println("立幅3横幅5の面積は、" + c);


	}

}
