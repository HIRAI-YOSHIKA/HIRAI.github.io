package sample06_comment;

public class Kouhan {

	public static void callDear() {
		System.out.println("えぇい、こしゃくな。曲者だ！であえい！");


	}

	public static void showMondokoro() throws Exception {
		System.out.println("飛車さん、角さん。もういいでしょう。");

		System.out.println("この紋所が目に入らぬか！");

		Thread.sleep(3000);				//java APIで提供されるjava.langパッケージThreadでsleepを使うのでsleepの前にthreadをいれる
										// ミリ秒（3秒 3000ミリ秒）

		sample06_comment.Zenhan.doTogame(); //もう一度、とがめる
	}

}				//Kouhan()
