package sample06_comment;

public class Main {

	public static void main(String[] args) throws Exception{

		Zenhan.doWarusa();
		Zenhan.doTogame();
		sample06_comment.Kouhan.callDear();
		sample06_comment.Kouhan.showMondokoro();   //ここで定義しているのでimportいらない


	}			//Main()X

}


