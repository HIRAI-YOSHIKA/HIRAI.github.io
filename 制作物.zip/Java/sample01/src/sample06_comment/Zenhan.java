package sample06_comment;

public class Zenhan {

	public static void doWarusa() {
		System.out.println("きな粉でござる。食えませんがの。");


	}

	public static void doTogame() {
		System.out.println("このおいぼれの目はごまかされませんぞ");


	}
				// Zenhan()

}