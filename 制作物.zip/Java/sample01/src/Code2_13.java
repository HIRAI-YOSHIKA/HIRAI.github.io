
public class Code2_13 {

	public static void main(String[] args) {
		//文字列をageを宣言し、"31"を代入

		String age = "31";
		//ageの中身をint型に変換して、int型変巣nに格納
		int n = Integer.parseInt(age);
		System.out.println
		       ("あなたは来年、" + (n +1) + "歳になりますね");

		//数字になれない数字をint型に変換できない
		//	例外（エラーの一種になる）
	}

}
