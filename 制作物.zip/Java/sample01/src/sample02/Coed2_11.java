package sample02;

public class Coed2_11 {

	public static void main(String[] args) {

		String name = "すがわら";

		System.out.println("私の名前は");
		System.out.println(name);
		System.out.println("です");

	}

}
