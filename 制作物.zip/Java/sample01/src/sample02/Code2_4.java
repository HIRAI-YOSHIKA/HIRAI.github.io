package sample02;

public class Code2_4 {

	public static void main(String[] args) {

		int  a;

		a = 100;
		a++;
		System.out.println(a);
		


	}

}
