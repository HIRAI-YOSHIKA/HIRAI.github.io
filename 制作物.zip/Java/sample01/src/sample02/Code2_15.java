package sample02;

public class Code2_15 {

	public static void main(String[] args) {

		System.out.println("あなたの名前を入力してください");

		//文字列変数nameを宣言して、キーボードからの入力を受け付ける
		String name = new java.util.Scanner(System.in).nextLine();

		System.out.println("あなたの年齢を入力してください");

		//int型変数ageを宣言して、キーボードからの入力を受け付ける
		int age = new java.util.Scanner(System.in).nextInt();

		System.out.print
	    ("ようこそ、" + age + "歳の" + name + "さん");



	}

}
