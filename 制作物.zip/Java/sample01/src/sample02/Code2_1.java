package sample02;

public class Code2_1 {

	public static void main(String[] args) {
//int型の変数aを宣言
		int a;
//int型の変数bを宣言
        int b;
//変数aに20代入
		a = 20;
//足し算んと代入
		b = a + 5;


		System.out.println(a);

		System.out.println(b);
	}
}