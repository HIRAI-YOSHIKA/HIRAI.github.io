package sample02;

public class Code2_7 {

	public static void main(String[] args) {
//		int型の変数ageを宣言して、3.2を強制的にint型に変数に代入
        int age = (int) 3.2;
//		ageの中身を表示
		System.out.println(age);



	}

}
