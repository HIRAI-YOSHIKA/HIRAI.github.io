﻿namespace BookManager
{


    partial class BookDataSet
    {
        partial class bookDataTableDataTable
        {
        }
    }
}
