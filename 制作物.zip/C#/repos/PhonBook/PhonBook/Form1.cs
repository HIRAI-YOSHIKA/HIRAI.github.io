﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhonBook
{
    public partial class Form1 : Form
    {
        Dictionary<string, string> phoneBook;

        public Form1()
        {
            InitializeComponent();

            this.phoneBook = new Dictionary<string, string>();

            //電話帳に名前を登録
            //this.phoneBook.Add("山田一郎", "xxx-3456-4343");
            //this.phoneBook.Add("山田二郎", "xxx-8823-9434");
            //this.phoneBook.Add("山田三郎", "xxx-7793-2117");
            //this.phoneBook.Add("山田史郎", "xxx-1693-7364");


            //ファイルからデータを読み込む

            ReadFromFile();



            //リストに名前を表示
          
            //foreach(拡張for文と同じ)で変数phoneBookから
            //キーと値がペアになったkeyValuePairという型でデータを取得
            //キーを取り出したい場合　変数名、keyで取得
            //値を取り出したい場合　変数名、Valueで取得

            foreach (KeyValuePair<string, string> date in phoneBook)
            {
                
                //phoneBook変数に登録した名前をListBoxに(Add()で)追加
                //ListBoxはItemsプロパティを持っており
                //Items.Add(追加する値)で引数に指定したデータを追加可能
                //Itemsプロパティに追加した値はフォーム上のListBoxに表示される

                this.nameList.Items.Add(date.Key);
            }

        }

        //データを読み込むメソッドを作る
       
        public void ReadFromFile()
        {
            //テキストファイルを読み込むにはStreamReaderクラスを使用する必要がある  （..\ は../と同じ　一個前を見る意味　＠を付けることにより￥　エスケープシーケンスとの区別化を図っている）
            //読み込む処理が終わったら確実にテキストファイルを閉じる必要があるため
            //usingステートメントで囲む必要がある
            using (System.IO.StreamReader file = new System.IO.StreamReader(@"..\..\data.text"))
            {


                //（難行読み込むかはプログラムを作る段階ではわからないためwhile文で1行ずつ読み込む)
                //条件式内 while(!file.EndOfStream)にすることで
                //最後の行まで読み込めたら繰り返しを終了させるようになっている

                while (!file.EndOfStream)
                {

                    //指定したファイルから1行ずつデータを読みとり、文字列として返す。(ReadLine())

                    string line = file.ReadLine();


                    //引数に与えた文字で文字列を区切り、string型の配列にする（Split()）
                    //split(',')で1番目名前、2番目に電話番号が入った配列を生成

                    string[] data = line.Split(',');



                    //名前と電話番号をペアにしてphoneBookにデータ登録している
                    //phoneBookはDictionary型なので、電話帳のデータが後から追加登録火可能

                    this.phoneBook.Add(data[0], data[1]);
                }
            }

        }


        private void NameSelected(object sender, EventArgs e)
        {
            //選択した名前に対応する電話番号を表示する

            //ListBoxで選択された名前をListBoxのTextプロパティで取得
            //name変数に代入

            string name = this.nameList.Text;



            //ListBoxで選択された名前をキーにして
            //対の電話番号をphoneBook[name]で取得
            //TextBoxのTextプロパティ（phoneNumber.Text）に
            //代入してフォーム画面に表示している

            this.phoneNumber.Text = this.phoneBook[name];
            
        }
    }
}
