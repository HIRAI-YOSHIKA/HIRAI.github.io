﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalData
{
    public partial class Form1 : Form
    {

        DateTime time = DateTime.Now;

        

        public Form1()
        {
            InitializeComponent();

            TimeNow.Text += time;
        }

       

        //登録
        private void RegiClick(object sender, EventArgs e)
        {

            if (PatientName.Text == "")
            {
                MessageBox.Show("患者名が未入力です");
            } else　if (DrName.Text == "") {

                MessageBox.Show("担当Dr名が未定義です");
            } else
            {

                medicalDataSet12.MedicalDataTable.AddMedicalDataTableRow
                (
                    this.PatientName.Text,
                    this.MedicalName.Text,
                    this.Description.Text,
                    this.Danger.Text,
                    this.StartMasked.Text,
                    this.EndMasked.Text,
                    this.DrName.Text

                );
            }
            
             
        }

           
        


        //削除
        private void DeleClick(object sender, EventArgs e)
        {
            int row = this.medicalDataGrid.CurrentRow.Index;
            this.medicalDataGrid.Rows.RemoveAt(row);

        }


        //検索
        private void SearchClick(object sender, EventArgs e)
        {
            //カラムが文字列型の場合はシングルクォーテーション ' で囲み、日付/時刻型の場合はシャープ#で囲む
          //DataRow[] 変数名 = DataSet名.Tables["Table名"].Select("カラム名(演算子またはMin Max 比較する値(今回textBoxの値なので外に出す))")
            DataRow[] dataRows = medicalDataSet12.Tables["MedicalDataTable"].Select("患者名='" + Search.Text + "'");

            for (int i = 0; i < dataRows.Length; i++)
            {
                for (int j = 0; j < 6; j++)
                { //Label.Textに代入　
                    Label.Text += (string)dataRows[i][j] + ' ';
                }
            
               
            }
           
        }


        //使用終了
        private void EndMedicine(object sender, EventArgs e)
        {
            
            //3日前
            time = time.AddDays(-3);
            //年月日のみ取得
            string value = time.ToString("yyyy年MM月dd日");

                                                                                 //時間だがstring型なので''で囲む
            DataRow[] dataRows = medicalDataSet12.Tables["MedicalDataTable"].Select("使用終了日='" + value + "'");




            for (int i = 0; i < dataRows.Length; i++)
            {
                for (int j = 0; j < 2; j++)
                {

                    label9.Text += (string)dataRows[i][j] + ' ';
                    //赤色にする
                    label9.ForeColor = Color.Red;
                }
            }

        }
    }
}
