﻿namespace MedicalData
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MedicalName = new System.Windows.Forms.TextBox();
            this.Description = new System.Windows.Forms.TextBox();
            this.Danger = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.TextBox();
            this.RegiButton = new System.Windows.Forms.Button();
            this.DeleButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.medicalDataGrid = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.DrName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.PatientName = new System.Windows.Forms.TextBox();
            this.Label = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.StartMasked = new System.Windows.Forms.MaskedTextBox();
            this.EndMasked = new System.Windows.Forms.MaskedTextBox();
            this.TimeNow = new System.Windows.Forms.Label();
            this.患者名DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.薬品名DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.説明DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.禁忌DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.使用開始日DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.使用終了日DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.受け持ちDrDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicalDataTableBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.medicalDataSet12 = new MedicalData.MedicalDataSet1();
            this.medicalDataTableBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.medicalDataTableBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.medicalDataTableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.medicalDataSet11 = new MedicalData.MedicalDataSet1();
            this.medicalDataSet1 = new MedicalData.MedicalDataSet1();
            this.medicalDataTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.medicalDataTableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 316);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "薬品名";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 347);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "説明";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 381);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "禁忌";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 410);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "使用開始日";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 442);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "使用終了日";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(449, 303);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "検索";
            // 
            // MedicalName
            // 
            this.MedicalName.Location = new System.Drawing.Point(115, 309);
            this.MedicalName.Name = "MedicalName";
            this.MedicalName.Size = new System.Drawing.Size(169, 19);
            this.MedicalName.TabIndex = 6;
            // 
            // Description
            // 
            this.Description.Location = new System.Drawing.Point(116, 340);
            this.Description.Name = "Description";
            this.Description.Size = new System.Drawing.Size(169, 19);
            this.Description.TabIndex = 7;
            // 
            // Danger
            // 
            this.Danger.Location = new System.Drawing.Point(116, 374);
            this.Danger.Name = "Danger";
            this.Danger.Size = new System.Drawing.Size(169, 19);
            this.Danger.TabIndex = 8;
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(451, 318);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(171, 19);
            this.Search.TabIndex = 11;
            // 
            // RegiButton
            // 
            this.RegiButton.Location = new System.Drawing.Point(333, 401);
            this.RegiButton.Name = "RegiButton";
            this.RegiButton.Size = new System.Drawing.Size(75, 23);
            this.RegiButton.TabIndex = 12;
            this.RegiButton.Text = "登録";
            this.RegiButton.UseVisualStyleBackColor = true;
            this.RegiButton.Click += new System.EventHandler(this.RegiClick);
            // 
            // DeleButton
            // 
            this.DeleButton.Location = new System.Drawing.Point(333, 452);
            this.DeleButton.Name = "DeleButton";
            this.DeleButton.Size = new System.Drawing.Size(75, 23);
            this.DeleButton.TabIndex = 13;
            this.DeleButton.Text = "削除";
            this.DeleButton.UseVisualStyleBackColor = true;
            this.DeleButton.Click += new System.EventHandler(this.DeleClick);
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(628, 314);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(75, 23);
            this.SearchButton.TabIndex = 14;
            this.SearchButton.Text = "検索";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchClick);
            // 
            // medicalDataGrid
            // 
            this.medicalDataGrid.AutoGenerateColumns = false;
            this.medicalDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.medicalDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.患者名DataGridViewTextBoxColumn,
            this.薬品名DataGridViewTextBoxColumn,
            this.説明DataGridViewTextBoxColumn,
            this.禁忌DataGridViewTextBoxColumn,
            this.使用開始日DataGridViewTextBoxColumn,
            this.使用終了日DataGridViewTextBoxColumn,
            this.受け持ちDrDataGridViewTextBoxColumn});
            this.medicalDataGrid.DataSource = this.medicalDataTableBindingSource5;
            this.medicalDataGrid.Location = new System.Drawing.Point(47, 37);
            this.medicalDataGrid.Name = "medicalDataGrid";
            this.medicalDataGrid.RowTemplate.Height = 21;
            this.medicalDataGrid.Size = new System.Drawing.Size(725, 230);
            this.medicalDataGrid.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 474);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 12);
            this.label7.TabIndex = 16;
            this.label7.Text = "受け持ちDr.";
            // 
            // DrName
            // 
            this.DrName.Location = new System.Drawing.Point(116, 467);
            this.DrName.Name = "DrName";
            this.DrName.Size = new System.Drawing.Size(169, 19);
            this.DrName.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 276);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 18;
            this.label8.Text = "患者名";
            // 
            // PatientName
            // 
            this.PatientName.Location = new System.Drawing.Point(116, 273);
            this.PatientName.Name = "PatientName";
            this.PatientName.Size = new System.Drawing.Size(169, 19);
            this.PatientName.TabIndex = 19;
            // 
            // Label
            // 
            this.Label.AutoSize = true;
            this.Label.Location = new System.Drawing.Point(492, 356);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(9, 12);
            this.Label.TabIndex = 20;
            this.Label.Text = " ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(530, 442);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(9, 12);
            this.label9.TabIndex = 21;
            this.label9.Text = " ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(628, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "使用終了間近";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.EndMedicine);
            // 
            // StartMasked
            // 
            this.StartMasked.Location = new System.Drawing.Point(116, 405);
            this.StartMasked.Mask = "0000年90月90日";
            this.StartMasked.Name = "StartMasked";
            this.StartMasked.Size = new System.Drawing.Size(169, 19);
            this.StartMasked.TabIndex = 23;
            this.StartMasked.ValidatingType = typeof(System.DateTime);
            // 
            // EndMasked
            // 
            this.EndMasked.Location = new System.Drawing.Point(116, 435);
            this.EndMasked.Mask = "0000年90月90日";
            this.EndMasked.Name = "EndMasked";
            this.EndMasked.Size = new System.Drawing.Size(168, 19);
            this.EndMasked.TabIndex = 24;
            this.EndMasked.ValidatingType = typeof(System.DateTime);
            // 
            // TimeNow
            // 
            this.TimeNow.AutoSize = true;
            this.TimeNow.Location = new System.Drawing.Point(25, 13);
            this.TimeNow.Name = "TimeNow";
            this.TimeNow.Size = new System.Drawing.Size(9, 12);
            this.TimeNow.TabIndex = 25;
            this.TimeNow.Text = " ";
            // 
            // 患者名DataGridViewTextBoxColumn
            // 
            this.患者名DataGridViewTextBoxColumn.DataPropertyName = "患者名";
            this.患者名DataGridViewTextBoxColumn.HeaderText = "患者名";
            this.患者名DataGridViewTextBoxColumn.Name = "患者名DataGridViewTextBoxColumn";
            // 
            // 薬品名DataGridViewTextBoxColumn
            // 
            this.薬品名DataGridViewTextBoxColumn.DataPropertyName = "薬品名";
            this.薬品名DataGridViewTextBoxColumn.HeaderText = "薬品名";
            this.薬品名DataGridViewTextBoxColumn.Name = "薬品名DataGridViewTextBoxColumn";
            // 
            // 説明DataGridViewTextBoxColumn
            // 
            this.説明DataGridViewTextBoxColumn.DataPropertyName = "説明";
            this.説明DataGridViewTextBoxColumn.HeaderText = "説明";
            this.説明DataGridViewTextBoxColumn.Name = "説明DataGridViewTextBoxColumn";
            // 
            // 禁忌DataGridViewTextBoxColumn
            // 
            this.禁忌DataGridViewTextBoxColumn.DataPropertyName = "禁忌";
            this.禁忌DataGridViewTextBoxColumn.HeaderText = "禁忌";
            this.禁忌DataGridViewTextBoxColumn.Name = "禁忌DataGridViewTextBoxColumn";
            // 
            // 使用開始日DataGridViewTextBoxColumn
            // 
            this.使用開始日DataGridViewTextBoxColumn.DataPropertyName = "使用開始日";
            this.使用開始日DataGridViewTextBoxColumn.HeaderText = "使用開始日";
            this.使用開始日DataGridViewTextBoxColumn.Name = "使用開始日DataGridViewTextBoxColumn";
            // 
            // 使用終了日DataGridViewTextBoxColumn
            // 
            this.使用終了日DataGridViewTextBoxColumn.DataPropertyName = "使用終了日";
            this.使用終了日DataGridViewTextBoxColumn.HeaderText = "使用終了日";
            this.使用終了日DataGridViewTextBoxColumn.Name = "使用終了日DataGridViewTextBoxColumn";
            // 
            // 受け持ちDrDataGridViewTextBoxColumn
            // 
            this.受け持ちDrDataGridViewTextBoxColumn.DataPropertyName = "受け持ちDr.";
            this.受け持ちDrDataGridViewTextBoxColumn.HeaderText = "受け持ちDr.";
            this.受け持ちDrDataGridViewTextBoxColumn.Name = "受け持ちDrDataGridViewTextBoxColumn";
            // 
            // medicalDataTableBindingSource5
            // 
            this.medicalDataTableBindingSource5.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource5.DataSource = this.medicalDataSet12;
            // 
            // medicalDataSet12
            // 
            this.medicalDataSet12.DataSetName = "MedicalDataSet1";
            this.medicalDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalDataTableBindingSource4
            // 
            this.medicalDataTableBindingSource4.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource4.DataSource = this.medicalDataSet12;
            // 
            // medicalDataTableBindingSource3
            // 
            this.medicalDataTableBindingSource3.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource3.DataSource = this.medicalDataSet12;
            // 
            // medicalDataTableBindingSource1
            // 
            this.medicalDataTableBindingSource1.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource1.DataSource = this.medicalDataSet11;
            // 
            // medicalDataSet11
            // 
            this.medicalDataSet11.DataSetName = "MedicalDataSet1";
            this.medicalDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalDataSet1
            // 
            this.medicalDataSet1.DataSetName = "MedicalDataSet1";
            this.medicalDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalDataTableBindingSource
            // 
            this.medicalDataTableBindingSource.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource.DataSource = this.medicalDataSet1;
            // 
            // medicalDataTableBindingSource2
            // 
            this.medicalDataTableBindingSource2.DataMember = "MedicalDataTable";
            this.medicalDataTableBindingSource2.DataSource = this.medicalDataSet12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 508);
            this.Controls.Add(this.TimeNow);
            this.Controls.Add(this.EndMasked);
            this.Controls.Add(this.StartMasked);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Label);
            this.Controls.Add(this.PatientName);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.DrName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.medicalDataGrid);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.DeleButton);
            this.Controls.Add(this.RegiButton);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Danger);
            this.Controls.Add(this.Description);
            this.Controls.Add(this.MedicalName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalDataTableBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MedicalName;
        private System.Windows.Forms.TextBox Description;
        private System.Windows.Forms.TextBox Danger;
        private System.Windows.Forms.TextBox Search;
        private System.Windows.Forms.Button RegiButton;
        private System.Windows.Forms.Button DeleButton;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.DataGridView medicalDataGrid;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource;
        private MedicalDataSet1 medicalDataSet1;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource1;
        private MedicalDataSet1 medicalDataSet11;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource2;
        private MedicalDataSet1 medicalDataSet12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox DrName;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox PatientName;
        private System.Windows.Forms.Label Label;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource4;
        private System.Windows.Forms.DataGridViewTextBoxColumn 患者名DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 薬品名DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 説明DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 禁忌DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 使用開始日DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 使用終了日DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 受け持ちDrDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource medicalDataTableBindingSource5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MaskedTextBox StartMasked;
        private System.Windows.Forms.MaskedTextBox EndMasked;
        private System.Windows.Forms.Label TimeNow;
    }
}

