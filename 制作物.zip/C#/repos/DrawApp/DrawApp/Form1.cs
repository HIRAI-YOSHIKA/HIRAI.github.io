﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrawApp
{
    public partial class Form1 : Form
    {
       

        //始点、終点座標を保持するPoint型のstartPosとendPosを宣言
        Point startPos, endPos;

        //Pallet型palletを宣言
        Pallet pallet;

        public Form1()
        {
            InitializeComponent();

            this.pallet = new Pallet();
            //Show() コンソールを表示
            pallet.Show();


        }

        //フォームメソッド
        private void DrawFigures(object sender, PaintEventArgs e)
        {

            // int type = 2;  //図形の種類
            // Color color = Color.Purple; //　図形の色
            // int penSize = 3; //　ペンの太さ


            int type = this.pallet.GetFigureType();
            Color color = this.pallet.GetColor();
            int penSize = this.pallet.GetPenSize();


            if (type == 1)
            {   //円
                SolidBrush brush = new SolidBrush(color);

                int width = this.endPos.X - this.startPos.X;
                int height = this.endPos.Y - this.startPos.Y;
                e.Graphics.FillEllipse(brush, this.startPos.X, this.startPos.Y, width, height);

            }
            else if (type == 2) //長方形を描画する
            {   
                SolidBrush brush = new SolidBrush(color);
                int width = this.endPos.X - this.startPos.X;
                int height = this.endPos.Y - this.startPos.Y;


                //長方形を描画するためにはFillRectangle()を使う。ｊ
                e.Graphics.FillRectangle(brush, this.startPos.X, this.startPos.Y, width, height);
                
            }　
            else if (type == 3) //直線を描画する
            {   //直線を書くにはペンを作る必要がある
                Pen p = new Pen(color, penSize);

                e.Graphics.DrawLine(p, this.startPos.X, startPos.Y, this.endPos.X, this.endPos.Y);

            }




            //円を描画する
            //塗りつぶした図形の場合塗りつぶすためのブラシ必要　SolidBrush型で作れる
            //SolidBrush()の引数に図形の色を入れる（Color.Purple）
            //変数brushに代入
            //SolidBrush brush = new SolidBrush(Color.Purple);
            
            //startPosからendPosの範囲で円を描画
            //int width = this.endPos.X - this.startPos.X;
            //int height = this.endPos.Y - this.startPos.Y;
            //e.Graphics.FillEllipse(brush, this.startPos.X, this.startPos.Y, width, height);


            //FillEllipseメソッドを使用　（円を描くとき）
            //第一引数　図形を塗りつぶすブラシ
            //第二・第三引数　始点座標
            //第四・第五引数　幅と高さを指定
          //  e.Graphics.FillEllipse(brush, 0, 0, 200, 200);

          //  SolidBrush brush2 = new SolidBrush(Color.Pink);
          //  e.Graphics.FillEllipse(brush2, 250, 250, 300, 150);

        }


        private void MousePressed(object sender, MouseEventArgs e)
        {

            //円の始点座標をsrartPosに保存する
            //マウスがクリックされたときに始点座標をstartPosに代入される
            this.startPos = new Point(e.X, e.Y);

            

        }

        private void MouseDragged(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)  //ドラッグしている場合
            {
                //終点座標を更新する
                //ドラッグしている間はendPosに代入され続ける
                   this.endPos = new Point(e.X, e.Y);

                Invalidate();

            }




        }
    }
}
