﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeGame
{
    class Program
    {
        static char[] map = {
                '#','#','#','#','#',
                '#',' ',' ',' ','#',
                '#',' ','#',' ','#',
                '#','P','#','G','#',
                '#','#','#','#','#',
        };

        static void DrawMap()
        {
            //マップを表示
            for (int i = 0; i < map.Length; i++)
            {
                //WriteLineで改行させない
                Console.Write(map[i]);

                //インデックス＋1　が　5の倍数になったとき改行をする
                if ((i + 1) % 5 == 0)
                {   //改行して表示（NewLine 新しいライン　改行の意味）（Enviroment 環境という意味）
                    Console.Write(System.Environment.NewLine);
                }
            }

        }

        static void MovePlayer(string key)
        {
           

            //プレイヤーの現在地を取得
            int playerPos = Array.IndexOf(map, 'P');

            //キーの入力に応じてプレイヤーを移動させる位置を決める
            int playerNextPos = 0;

            //受け付けた文字は文字列としてうけとるため("a")で囲む
            if (key == "a")
            {   //左に移動
                playerNextPos = playerPos - 1;

            }
            else if (key == "d")
            {   //右に移動
                playerNextPos = playerPos + 1;
            }
            else if (key == "w")
            {   //上に移動
                playerNextPos = playerPos - 5;
            }
            else if (key == "s")
            {   //下に移動
                playerNextPos = playerPos + 5;
            }
            else
            {
                return;
            }

            if (map[playerNextPos] != '#')
            {

                //プレイヤーの現在地を更新
                map[playerNextPos] = 'P';
                map[playerPos] = ' ';
            }


        }
         

        //ゴール判定メソッド
        static bool CheckGoal()
        {
            //map内に'G'の文字がない場合はtrue ある場合　falseを返す
            if (Array.IndexOf(map,'G') < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


         static void Main(string[] args)
         {

            // 初期値のマップ表記
            DrawMap();

            //繰り返し入力受け付けるコード

            while (true)
            {
                string key = Console.ReadLine();


                //プレイヤーの移動
                MovePlayer(key);



                //ゴールしたらwhile文を抜けてゲームクリア
                if (CheckGoal())
                {
                    break;
                }
                //更新後のマップ表示(外に出すとマップがゴール時以外見えなくなる　感覚でゴールするようなゲームの場合使われたりする)
                DrawMap();

            }
           

            Console.WriteLine("ゲームクリア！");

           
        }
    }
}
