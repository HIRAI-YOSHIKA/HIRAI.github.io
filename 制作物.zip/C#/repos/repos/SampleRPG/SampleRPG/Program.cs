﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleRPG
{
    class Program
    {
        static void Main(string[] args)
        {

            Player player = new Player("たかし", 500);

            player.Hp -= 2000;
            Console.WriteLine("HPは" + player.Hp);

        }
    }
}
