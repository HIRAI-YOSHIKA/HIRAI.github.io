﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleRPG
{
    class Monster
    {
        public int hp;
        public string name;

        public void Attack()
        {
            Console.WriteLine("敵の攻撃！");
            
        }

        public void Escape()
        {
            Console.WriteLine("逃げられた");
        }
    }
}
