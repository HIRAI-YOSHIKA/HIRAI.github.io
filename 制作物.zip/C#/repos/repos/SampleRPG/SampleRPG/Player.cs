﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleRPG
{
    class Player
    {   //フィールド変数
        private string name;
        private int hp;


        //コンストラクター
        public Player(string name, int hp)
        {
            this.name = name;
            this.hp = hp;
        }


        //hp変数に値を代入する
        public void SetHp(int hp)
        {
           this.hp = hp;
            if (this.hp < 0) 
            {
                this.hp = 0;
            }
        }

        public int GetHp() 
        {
            return this.hp;
        }


          //攻撃用メソッド
        public void Attack()
        {
            Console.WriteLine(this.name + "は攻撃をした");
        }
        //防御用メソッド
        public void Defense()
        {
            Console.WriteLine(this.name + "は防御をした");
        }
    }
}
