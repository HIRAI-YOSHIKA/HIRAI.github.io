﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleRPG
{
    class Shop
    {
        public string shopName;
        public int salesAmount;

        //販売メソッド
        public void Sell()
        {
            Console.WriteLine("お買い上げありがとうございます!");

        }
        //買取メソッド
        public void Buy()
        {
            Console.WriteLine("お売りいただきありがとうございます！");
        }

    }
}
