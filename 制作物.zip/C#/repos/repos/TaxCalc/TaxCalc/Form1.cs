﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaxCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcButtonClicked(object sender, EventArgs e)
        {
            int price;
            //TryParse()文字列型を数値型に変換するメソッド　
            //第一引数の文字列が正しく変換出来たら第二引数に変換後の値を代入し戻り値にtrue
           //変換出来なかった場合falseを返す（変数に0が入る）　
            bool success = int.TryParse(this.priceBox.Text, out price);

            if (success)
            {
                //消費税を計算する
                int taxPrice = (int)(price * 1.08);
                this.taxPriceBox.Text = taxPrice.ToString();
            } else
            {
                //false　エラーメッセージを表示
                //MessageBox.Show()を使用　（）の中に表示したい文字列をいれる
                MessageBox.Show("税抜き価格を正しく入力してください");
            }
        }
    }
}
