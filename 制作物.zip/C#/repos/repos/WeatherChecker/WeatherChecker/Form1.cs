﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace WeatherChecker
{
    public partial class Form1 : Form
    {

        Dictionary<string, string> cityNames;
        public Form1()
        {
            InitializeComponent();

            this.cityNames = new Dictionary<string, string>();
            this.cityNames.Add("東京都", "3");
            this.cityNames.Add("大阪府", "1");
            this.cityNames.Add("宮城県", "4");
            this.cityNames.Add("北海道", "5");
            this.cityNames.Add("新潟県", "6");
            this.cityNames.Add("石川県", "7");
            this.cityNames.Add("広島県", "8");
            this.cityNames.Add("高知県", "9");
            this.cityNames.Add("鹿児島", "11");
            this.cityNames.Add("沖縄県", "12");
            this.cityNames.Add("愛知県", "2");
            this.cityNames.Add("福岡県", "10");



            foreach (KeyValuePair<string, string> data in this.cityNames)
            {
                areaBox.Items.Add(data.Key);

            }
        }



            
            private void CitySelected(object sender, EventArgs e)
            {
            //天気情報サービスにアクセスする

            //選択された都道府県を取得(areaBox.Text)
            //都道府県名をキー(key)に変えcityNamesの辞書から都道府県コードを取り出す
            string cityCode = cityNames[areaBox.Text];
            
            //天気情報サービスURLの後ろに都道府県コード（cityCode）をつなげている
            string url = "http://and-idea.sbcr.jp/sp/90261/weatherCheck.php?city=" + cityCode;

            //HttpClientクラスのGetStringAsync()を使用し
            HttpClient client = new HttpClient();

            //webサイトにアクセス、帰ってきた情報をResultプロパティで取得し(System.Http.HttpClient　インポート)
            //resultに代入
            string result = client.GetStringAsync(url).Result;

            //天気情報からアイコンのURLを取り出す
            //Parse()の引数にresultを渡しJSON形式のデータ解析し
            //JObject型jobjに代入
            JObject jobj = JObject.Parse(result);

            //jobj変数からお天気アイコンの情報を取り出し
            //[]の中にJSONから取り出したい項目のキー(url)を指定し
            //キーと対になる値を取り出している
            string todayweatherIcon = (string)((jobj["url"] as JValue).Value);
            
            //PictureBox(weatherlcon)のImageLocationプロパティにお天気アイコンURLを指定し
            //フォーム上に表示
            weatherlcon.ImageLocation = todayweatherIcon;


            }




        //フォームの終了が押されたら
        private void ExitMenuClicked(object sender, EventArgs e)
        {
            //フォームを閉じる
            this.Close();
        }
    }
}
