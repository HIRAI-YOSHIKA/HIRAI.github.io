-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 
-- サーバのバージョン： 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `practice_db_hirai`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `category` varchar(30) DEFAULT '未分類',
  `title` varchar(255) NOT NULL,
  `price` int(11) DEFAULT NULL,
  `updated` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `books`
--

INSERT INTO `books` (`id`, `category`, `title`, `price`, `updated`) VALUES
(1, '雑誌', '週刊少年ジャンプ', 300, '2018-08-31'),
(2, '雑誌', '週刊少年サンデー', 290, '2018-08-31'),
(3, '漫画', 'タッチ', 570, '2000-01-11'),
(4, '漫画', 'DRAGON BALL', 530, '1982-12-11'),
(5, '漫画', '北斗の拳', 380, '1983-02-27'),
(6, '小説', 'ノルウェイの森', 1700, '1987-05-26'),
(7, '小説', '海辺のカフカ', 1820, '2004-08-15'),
(8, '小説', '騎士団長殺し', 1820, '2017-03-10'),
(9, NULL, '君が僕を知ってる', 960, NULL),
(10, '小説', 'この世に猫がいなかったら', 1200, '2016-11-01'),
(12, NULL, 'スキー入門', 1340, '2018-09-01'),
(13, NULL, '必勝麻雀', 1420, '2018-09-01'),
(15, '漫画\r\n', 'Dr.SLUMP', 400, '1978-12-11'),
(16, '未分類', 'Java入門', 1800, NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `dogs`
--

CREATE TABLE `dogs` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(4) NOT NULL,
  `age` int(11) NOT NULL,
  `breed` varchar(40) NOT NULL DEFAULT '雑種',
  `owner_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `dogs`
--

INSERT INTO `dogs` (`id`, `name`, `sex`, `age`, `breed`, `owner_id`) VALUES
(1, '百円', 'オス', 12, '雑種', 2),
(2, 'ロッシ', 'オス', 14, 'ポメラニアン', 2),
(3, 'クロ', 'オス', 6, '柴犬', 2),
(4, 'めいこ', 'メス', 9, 'ゴールデン・レトリバー', 3),
(5, '春', 'メス', 8, 'ポメラニアン', 4),
(6, 'ナツ', 'メス', 11, 'ラブラドール・レトリバー', 5),
(7, 'マサ', 'オス', 12, 'ジャーマン・シェパード', 6),
(8, 'たけし', 'オス', 8, '柴犬', 8),
(9, 'シャルル', 'メス', 5, 'ポメラニアン', 9),
(10, 'ジェイク', 'オス', 12, 'ラブラドール・レトリバー', 10),
(11, 'みかん', 'メス', 18, 'アイリッシュ・クラウン', 11),
(12, 'チャンピィ', 'オス', 12, 'ジャーマン・シェパード', 12),
(13, 'よしき', 'オス', 8, '柴犬', NULL),
(14, 'セテ', 'オス', 16, 'ゴールデン・レトリバー', 2),
(15, 'はやて', 'メス', 3, 'ジャーマン・シェパード', 14),
(16, '幸音', 'メス', 12, '雑種', 2),
(17, 'ファーザー', 'オス', 4, 'ゴールデン・レトリバー', 15),
(18, 'れおん', 'オス', 2, '柴犬', NULL),
(19, 'ベへモス', 'メス', 6, 'ポメラニアン', 17);

-- --------------------------------------------------------

--
-- テーブルの構造 `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `employee`
--

INSERT INTO `employee` (`id`, `name`, `age`) VALUES
(1, 'ミナト', 20),
(2, 'アサカ', 21);

-- --------------------------------------------------------

--
-- テーブルの構造 `exam_1`
--

CREATE TABLE `exam_1` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `exam_1`
--

INSERT INTO `exam_1` (`id`, `name`, `score`) VALUES
(5, '動物の集まる森', 241),
(6, '最後の幻想', 551),
(7, '金属の歯車', 348),
(8, '戦う兄弟', 587);

-- --------------------------------------------------------

--
-- テーブルの構造 `monsters`
--

CREATE TABLE `monsters` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `hp` int(11) NOT NULL DEFAULT '1',
  `attack` int(11) NOT NULL DEFAULT '1',
  `defense` int(11) NOT NULL DEFAULT '1',
  `type` varchar(20) NOT NULL,
  `exp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `monsters`
--

INSERT INTO `monsters` (`id`, `name`, `hp`, `attack`, `defense`, `type`, `exp`) VALUES
(1, 'スライム', 1, 9, 11, 'スライム系', 2),
(2, 'ドラキー', 11, 12, 17, '鳥系', 4),
(3, 'リリパット', 29, 36, 42, '怪人系', 16),
(4, 'メタルスライム', 4, 45, 256, 'スライム系', 1206),
(5, 'キメラ', 176, 81, 86, '鳥系', 74),
(6, 'ばくだん岩', 216, 124, 165, '物質系', 90),
(7, 'あくま神官', 287, 108, 109, '悪魔系', 96),
(8, 'おどるほうせき', 370, 89, 100, '物質系', 84),
(9, 'くさった死体', 575, 79, 72, 'ゾンビ系', 152),
(10, 'じんめんじゅ', 406, 94, 105, '植物系', 117),
(11, 'オーク', 406, 119, 107, '獣系', 135),
(12, 'がいこつ', 483, 128, 138, 'ゾンビ系', 177),
(13, 'キングスライム', 570, 89, 100, 'スライム系', 166),
(14, 'ゴーレム', 858, 120, 158, '物質系', 300),
(15, 'キラーパンサー', 1343, 259, 226, '獣系', 692),
(16, 'キラーマシン', 1352, 240, 346, '物質系', 516),
(17, 'グレイトドラゴン', 10512, 815, 800, 'ドラゴン系', 3211),
(18, 'ギガンテス', 2022, 303, 218, '悪魔系', 769);

-- --------------------------------------------------------

--
-- テーブルの構造 `name_list`
--

CREATE TABLE `name_list` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `address` varchar(30) DEFAULT '日本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `name_list`
--

INSERT INTO `name_list` (`id`, `name`, `gender`, `age`, `address`) VALUES
(1, '斎藤', '男', 21, '東京都'),
(2, '仮谷', '女', 17, '京都府'),
(3, '戸畑', '女', 15, '福岡県'),
(4, '鈴木', '男', 23, '日本'),
(5, '山口', '男', 20, '宮城'),
(6, '太田', '男', 19, '福井'),
(8, '武田', '男', 25, '大阪府'),
(9, '大宮', '女', 19, '大分県');

-- --------------------------------------------------------

--
-- テーブルの構造 `omake`
--

CREATE TABLE `omake` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `birthday` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `omake`
--

INSERT INTO `omake` (`id`, `name`, `birthday`) VALUES
(1, 'タロウ', '1997-07-03'),
(2, 'ハナコ', '1999-09-14');

-- --------------------------------------------------------

--
-- テーブルの構造 `owners`
--

CREATE TABLE `owners` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `owners`
--

INSERT INTO `owners` (`id`, `name`) VALUES
(1, '武蔵'),
(2, '亮介'),
(3, 'おとーさん'),
(4, 'パパ'),
(5, 'ご主人様'),
(6, '八房'),
(7, 'おかあさん'),
(8, 'みーちゃん'),
(9, '美琴'),
(10, 'お姉さん'),
(11, 'お兄さん'),
(12, '祐一'),
(13, 'ママ'),
(14, '千恵'),
(15, '一久');

-- --------------------------------------------------------

--
-- テーブルの構造 `sample`
--

CREATE TABLE `sample` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(11) NOT NULL,
  `money` int(11) NOT NULL,
  `plus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `sample`
--

INSERT INTO `sample` (`id`, `name`, `age`, `money`, `plus`) VALUES
(1, 'タナカ', 24, 15000, 0),
(2, 'ヤマダ', 23, 30000, 0),
(3, 'ナカヤマ', 32, 56000, 0),
(4, 'ハセガワ', 19, 8000, 0),
(5, 'オオヤマ', 29, 63000, 0),
(6, 'オオバヤシ', 54, 41000, 0),
(7, 'エンユウジ', 18, 120000, 0),
(8, 'ホリ', 23, 500, 0);

-- --------------------------------------------------------

--
-- テーブルの構造 `score_table`
--

CREATE TABLE `score_table` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `day` date DEFAULT NULL,
  `address` varchar(30) DEFAULT '日本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `score_table`
--

INSERT INTO `score_table` (`id`, `name`, `score`, `day`, `address`) VALUES
(1, '佐藤', 1871, '2012-11-23', '東京'),
(2, '鈴木', 1797, '2004-06-13', '大阪'),
(3, '高橋', 1411, '2009-08-08', '大阪'),
(4, '田中', 1335, '2021-03-27', '大阪'),
(5, '伊藤', 1074, '2012-05-09', '日本'),
(17, '木村', 576, '2158-07-14', '東京');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `name`, `age`) VALUES
(5, 'ミナト', 20),
(6, 'アサカ', 21);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dogs`
--
ALTER TABLE `dogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_1`
--
ALTER TABLE `exam_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monsters`
--
ALTER TABLE `monsters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `name_list`
--
ALTER TABLE `name_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `omake`
--
ALTER TABLE `omake`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sample`
--
ALTER TABLE `sample`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `score_table`
--
ALTER TABLE `score_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `dogs`
--
ALTER TABLE `dogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `exam_1`
--
ALTER TABLE `exam_1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `monsters`
--
ALTER TABLE `monsters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `name_list`
--
ALTER TABLE `name_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `omake`
--
ALTER TABLE `omake`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `sample`
--
ALTER TABLE `sample`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `score_table`
--
ALTER TABLE `score_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
