-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 
-- サーバのバージョン： 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `docotsubu_hirai`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `account`
--

CREATE TABLE `account` (
  `ID` int(11) NOT NULL,
  `PASS` varchar(10) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `TEXT` varchar(50) DEFAULT NULL,
  `AGE` int(11) DEFAULT NULL,
  `TEL` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `account`
--

INSERT INTO `account` (`ID`, `PASS`, `NAME`, `TEXT`, `AGE`, `TEL`) VALUES
(1, '8877', '渥美', '涼しくなってきたね～', 24, '09064561254'),
(2, '1211', '中野', 'もう、秋ですね', 64, '09033689452'),
(3, '9876', '涼', '風も強いですね', 43, '08077984345'),
(4, '7777', '唯', '過ごしやすいね', 29, '09067338297'),
(5, 'Nakano', '1212', NULL, 27, '0120828828');

-- --------------------------------------------------------

--
-- テーブルの構造 `account2`
--

CREATE TABLE `account2` (
  `ID` int(11) NOT NULL,
  `PASS` varchar(10) DEFAULT NULL,
  `NAME` varchar(20) DEFAULT NULL,
  `TEXT` varchar(50) DEFAULT '_',
  `AGE` int(11) DEFAULT NULL,
  `TEL` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- テーブルの構造 `mutter`
--

CREATE TABLE `mutter` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `text` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- テーブルのデータのダンプ `mutter`
--

INSERT INTO `mutter` (`id`, `name`, `text`) VALUES
(1, '湊', '今日は休みだ'),
(2, '綾部', 'いいな～'),
(4, '涼', '6勤務中'),
(5, '奏音', '頑張るな～'),
(6, '777', 'aaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `account2`
--
ALTER TABLE `account2`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `mutter`
--
ALTER TABLE `mutter`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `account2`
--
ALTER TABLE `account2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mutter`
--
ALTER TABLE `mutter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
