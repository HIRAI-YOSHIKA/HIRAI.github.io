package chapter05;

public class Main_Q2 {

	public static void main(String[] args) {

		Student n = new Student("のび太", 0, 0, 0);

		Student s = new Student("すねお", 54, 31, 32);

		Student d = new Student("出木杉", 100, 100, 100);

		Student[] studentArray = new Student[3];

		studentArray[0] = new Student("のび太", 0, 0, 0);
		studentArray[1] = new Student("すねお", 54, 31, 32);
		studentArray[2] = new Student("出木杉", 100, 100, 100);

		for (Student st : studentArray) {

			System.out.println(st.makePrintData());

		}

		/*System.out.println(n.makePrintData());
		System.out.println(s.makePrintData());
		System.out.println(d.makePrintData());*/
	}

}
