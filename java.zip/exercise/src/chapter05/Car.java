package chapter05;

public class Car {

	double gasoline;		//ガソリン残量
	double nenpi;			//燃費
	double gasolineMax;		//ガソリンが入れることのできる最大数

//------------- フィールド変数 --------------------------------------------

	public Car(double gasoline, double nenpi, double gasolineMax) {
		//ガソリンのリットル
		this.gasoline = gasoline;
		//キロ/リットル
		this.nenpi = nenpi;
		//最大量
		this.gasolineMax = gasolineMax;
	}

//----------------- コンストラクタ -------------------------------------------


	/*一般メソッド*/
	public void displayGasoline() {		//ガソリン残量表示
		System.out.println("現在の燃料は" + this.gasoline + "です");
	}

	public void addGasoline(double gasoline) {			//給油が最大を超えないようする
		double refill = Math.min(this.gasolineMax - this.gasoline, gasoline);

		System.out.println(refill + "リットル給油します");

		this.gasoline += refill;		//ガソリン残量に給油(refill)を追加
		System.out.println("現在の燃料は" + this.gasoline + "リットルです");
	}

	/*一般メソッド*/
	public void run(double distance) {			//車を走行。

		if (this.gasoline - (distance / nenpi) >= 0) {
			this.gasoline -= distance / nenpi;
			System.out.println(distance + "走行します");

		} else {
			System.out.println("燃焼不足。走行できません");
		}






	}
}
