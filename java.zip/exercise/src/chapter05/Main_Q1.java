package chapter05;

public class Main_Q1 {

	public static void main(String[] args) {
		Car c = new Car(30, 8.4, 60);

//--------------- インスタンス化 ------------------------------------------



		int selectNum = 0;
		boolean result = false;
		while(selectNum != 4){
			System.out.println("1.走行 / 2. 給油 / 3. 残量表示 / 4.終了");

			selectNum = new java.util.Scanner(System.in).nextInt();

			switch (selectNum) {

			case 1:
				System.out.println("何キロ走行しますか");
				int x = new java.util.Scanner(System.in).nextInt();
				c.run(x);


				break;

			case 2:
				System.out.println("何リットル給油しますか");

				int y = new java.util.Scanner(System.in).nextInt();

				c.addGasoline(y);

				break;

			case 3:
				c.displayGasoline();

				break;

			case 4:
				System.out.println("アプリケーションを終了します");
				result = true;

			}
		}





	}


}
