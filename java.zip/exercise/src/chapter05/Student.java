package chapter05;

public class Student {
	String name;

	int[] scores = new int[3];  //先に配列変数の宣言

	//------------------- フィールド変数 ----------------------


	public Student(String s , int x, int y , int z){
		this.name = s;
		this.scores[0] = x;			//配列に代入
		this.scores[1] = y;
		this.scores[2] = z;

	}

	//---------------------- コンストラクタ ---------------------------------





	/*	合計点数を返す一般メソッド */
	public int calcTotal() {
		int value = 0;
		for (int score : scores) {
			value += score;
		}

		return value;
	}
	/*名前、各点、合計値を返す一般メソッド*/
	public String makePrintData() {

		String info = "";	//"";にしておくことでnullが出ないようにする

		info += (this.name + ":");	//名前入れる
		for (int i = 0; i < this.scores.length; i++) {
			info += this.scores[i] + ","; //配列に各点を入れる

		}
		info += "　合計点は";

		info += calcTotal();

		return info;
	}
}
