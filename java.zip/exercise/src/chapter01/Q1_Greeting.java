package chapter01;

public class Q1_Greeting {

	public static void main(String[] args) {

		System.out.println("私の名前は、南畑です");
	}

}
