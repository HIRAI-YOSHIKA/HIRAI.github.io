package chapter01;

public class Q10 {

	public static void main(String[] args) {
		int cnt = 0;

		for (int i = 0; i < 10; i++) {

			int ram = new java.util.Random().nextInt(101);
			//System.out.println(ram);

			if (ram >= 50) {	//　ramが５０以上ならば
				cnt += 1;		//　条件に当てはまればcntに1＋する
			}

		}
		System.out.println("50以上のscoreは" + cnt + "個ありました");



	}

}
