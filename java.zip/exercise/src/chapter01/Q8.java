package chapter01;

public class Q8 {

	public static void main(String[] args) {
		int ran = new java.util.Random().nextInt(101);
		System.out.println(ran);
		if (ran >= 80) {
			System.out.println("Excellent!");
		} else if (ran >= 50) {
			System.out.println("Good");
		} else {
			System.out.println("Bad");
		}

	}

}
