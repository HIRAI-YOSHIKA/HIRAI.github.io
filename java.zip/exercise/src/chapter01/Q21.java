package chapter01;

public class Q21 {

	public static void main(String[] args) {



		int num = 777;
		int cnt = 0;
		while (true) {
			 cnt++;

			 int ram = new java.util.Random().nextInt(1000);

			 if (ram == num) {
				 break;

			 }


		} System.out.println(num + "は" + cnt + "回目にでました");

	}

}
