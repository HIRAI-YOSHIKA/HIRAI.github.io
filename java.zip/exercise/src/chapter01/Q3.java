package chapter01;

public class Q3 {

	public static void main(String[] args) {
		int x = 10;
		int i = 0;
		while(i < 3) {
			i++;
			x += 5;


		}
		System.out.println("Ans:" + x);


	}

}
