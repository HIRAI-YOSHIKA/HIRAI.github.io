package chapter01;

public class Q24 {

	public static void main(String[] args) {

		System.out.println("ｘに代入する数値を入力してください");
		int x = new java.util.Scanner(System.in).nextInt();


		System.out.println("ｙに代入する数値を入力してください");
		int y = new java.util.Scanner(System.in).nextInt();

		int box = 0;

		box = x;
		x = y;
		y = box;

		System.out.println("2つの数値を入れてください" + "x:" + x + " y:" + y);
	}
}
