package chapter01;

public class Q9 {

	public static void main(String[] args) {
		int cnt = 5;
		int sam = 0;

		for (int i = 0; i < cnt; i++) {


			sam += new java.util.Random().nextInt(10);
			System.out.println(sam);

		}
		    double avg = (double)sam / cnt;
			System.out.println("5この数値の合計は" + sam + "平均は" + avg);
	}

}
