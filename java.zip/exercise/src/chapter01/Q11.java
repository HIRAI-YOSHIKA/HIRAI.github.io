package chapter01;

public class Q11 {

	public static void main(String[] args) {
		System.out.println("英語で10月を小文字で入力してください");
		String month = new java.util.Scanner(System.in).nextLine();

		if (month.equals("october")) {
			System.out.println("OK!");


		} else {
			System.out.println("NG");


		}
	}



}
