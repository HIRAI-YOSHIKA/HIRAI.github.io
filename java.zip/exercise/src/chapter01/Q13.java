package chapter01;

public class Q13 {

	public static void main(String[] args) {

		System.out.println("日本の信号で渡ってもよい色は？（漢字一文字）");

		String color = new java.util.Scanner(System.in).nextLine();


		switch (color) {
		case "緑":
			System.out.println("OK!");

		break;

		case "青":
			System.out.println("OK!");
			break;

			default:
				System.out.println("NG");

		}


	}


}
