package chapter01;

public class Q16 {

	public static void main(String[] args) {

		int ram = 0;
		int cut = 0;
		do {
			ram = new java.util.Random().nextInt(101);
			System.out.println(ram);
			cut++;


		} while (ram != 100);
		System.out.println(cut + "回目に１００が出ました");

	}
}
