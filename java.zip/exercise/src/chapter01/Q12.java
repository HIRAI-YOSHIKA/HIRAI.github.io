package chapter01;

public class Q12 {

	public static void main(String[] args) {
		System.out.println("スペイン語で日曜日は何？　1: Lunes 2: Jueves 3: Domingo");

		int i = new java.util.Scanner(System.in).nextInt();


		switch (i) {
		case 1:
			System.out.println("NG");
			break;
		case 2:
			System.out.println("NG");
			break;

		case 3:
			System.out.println("OK!");
			break;

		}



		/*if (i == 3) {
			System.out.println("OK!");
		} else {
			System.out.println("NG");
		}*/

	}

}
