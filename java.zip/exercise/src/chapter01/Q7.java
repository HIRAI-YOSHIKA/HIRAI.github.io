package chapter01;

public class Q7 {

	public static void main(String[] args) {

		System.out.println("スカイツリーの高さは？");
		int  input = new java.util.Scanner(System.in).nextInt();
		if (input == 634) {

			System.out.println("OK!");

		} else {
			System.out.println("NG");
		}

	}

}
