package chapter01;

public class Greeting {

	public static void main(String[] args) {

		System.out.println("南畑です。こんにちは");


	}

}
