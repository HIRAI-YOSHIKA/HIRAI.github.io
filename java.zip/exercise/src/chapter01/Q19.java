package chapter01;

public class Q19 {

	public static void main(String[] args) {

		System.out.println("いくつ★を表示させますか？ご希望の数をご入力ください");

		int num = new java.util.Scanner(System.in).nextInt();



		for (int i = 0; i < num; i++) {

			System.out.print("★");
		}


	}
}
