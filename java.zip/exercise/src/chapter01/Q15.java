package chapter01;

public class Q15 {

	public static void main(String[] args) {
		int ans = 0;

		for (int i = 1; i <= 100; i++) {
			ans += i;

		}
		System.out.println("1から１００まで足すと" + ans + "です");

	}

}
