package chapter01;

public class Q2_Greeting {

	public static void main(String[] args) {

		int x = 23;
		int y = 6;

		System.out.println("x + y = " + (x + y));
		System.out.println("x + y = " + (x - y));
		System.out.println("x + y = " + (x * y));
		System.out.println("x + y = " + (x / y));
		System.out.println("x + y = " + (x % y));

	}

}
