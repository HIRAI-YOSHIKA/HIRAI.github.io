package chapter01;

public class Q14 {

	public static void main(String[] args) {
		int ans = 0;

		int x = new java.util.Random().nextInt(6);
		x++;
		System.out.println(x);
		int y = new java.util.Random().nextInt(6);
		y++;
		System.out.println(y);



		if(x == y) {
			ans = (x + y) * 2;
			System.out.println("dice1:" + x + "dice2:" + y + "score" + ans);

		} else {
			ans = x + y;
			System.out.println("dice1:" + x + "dice2:" + y + "score" + ans);

		}



	}

}
