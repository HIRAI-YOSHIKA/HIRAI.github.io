package chapter01;

public class Q22 {

	public static void main(String[] args) {

		for (int i = 1; i < 10; i++) {
			for (int j = 1; j < 10; j++) {
				int ans = i * j;
				if (ans > 50) { // i * j 50以上ならば...
					break;		// 上記のとおりならば終わります
				}

				System.out.print(ans + " ");
			}
				System.out.println(" ");

		}

	}

}
