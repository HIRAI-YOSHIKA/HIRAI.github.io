package chapter01;

public class Q5 {
	public static void main(String[] args) {
		double bottom = 4.3;
		double height = 5.4;

		double i = bottom * height / 2.0;
		System.out.println("底辺：4.3.高さ：5.4の三角系の面積は：" + i);

	}
}
