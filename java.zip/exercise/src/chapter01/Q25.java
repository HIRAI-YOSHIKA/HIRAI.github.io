package chapter01;

public class Q25 {

	public static void main(String[] args) {

		int x = new java.util.Random().nextInt(21);
		int y = new java.util.Random().nextInt(21);
		int z = new java.util.Random().nextInt(21);

		int r = 0;
			if (x > y) {
				r = x;
				x = y;
				y = r;
			} if (x > z) {
				r = x;
				x = z;
				z = r;

			} if (y > z){
				r = y;
				y = z;
				z = r;
			}
			 System.out.println(x + "," + y + "," + z);		//全部同じ数はどうなるのか 同じだから関係ないのか

	}

}
