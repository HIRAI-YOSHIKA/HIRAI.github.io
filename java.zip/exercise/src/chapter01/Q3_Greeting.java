package chapter01;

public class Q3_Greeting {

	public static void main(String[] args) {


		int x = 10;

		int i = 1;


		while (i <= 3) { // 3回繰り返す
			x += 5; //xに＋される数を代入する

			i++;

		}

		System.out.println(x);


	}

}
