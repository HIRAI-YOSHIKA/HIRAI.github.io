package chapter07;

public interface Creature {

	void live();			//インタフェース内なら省略可能



}
