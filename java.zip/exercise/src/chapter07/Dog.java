package chapter07;

public class Dog extends Animal {

	public Dog(String name, String voice) {
		super(name, voice);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	@Override
	public void live() {				//生活（live）
		System.out.println(this.name + "は無邪気に生活する");
	}

}
