package chapter07;

public class PC {

//-------------- 	フィールド変数 ------------------------------------------

	UsbConnectable device;

//-------------- 	フィールド変数 ------------------------------------------

//---------------------- メソッド ------------------------------------------
	public void execApp() {

		if(this.device == null){
			System.out.println("アプリケーションを実行できます。先にUSBを接続して下さい");
		} else {
			device.usbConnect();
		}


	}



	/*----------------------- getter / setter メソッド --------------------------------*/
	public UsbConnectable getDevice() {

		return this.device;
	}

	public void setDevice(UsbConnectable device) {
		this.device = device;
	}
	/*------------------------------------------------------------------------*/

}
