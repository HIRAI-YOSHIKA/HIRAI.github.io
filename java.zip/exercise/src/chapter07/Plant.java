package chapter07;

public abstract class Plant implements Creature {
	//フィルード変数
	String name;
	String color;


	//コンストラクタ
	public Plant(String name, String color) {
		this.name = name;
		this.color = color;
	}


	@Override
	public abstract void live();

	// 出力させるメソッド 花を咲かせる。
	public void makeFlowers() {
		System.out.println(this.name  + "は" + this.color + "の花を咲かせる");


	}
}
