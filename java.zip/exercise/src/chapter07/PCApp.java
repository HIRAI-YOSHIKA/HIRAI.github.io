package chapter07;

public class PCApp {

	public static void main(String[] args) {
		int number = 0;
		boolean flag = false;

		PC pc = new PC();


		Mouse mo = new Mouse();
		Memory me = new Memory();
		CardReader ca = new CardReader();


		while (number != 3) {

			System.out.println("0:アプリ実行 1:USBデバイス接続  2:USBデバイス取り外し  3:終わり");
			number = new java.util.Scanner(System.in).nextInt();

			switch (number) {
				case 0:

					pc.execApp();			//接続前はnullなのでそのままメソッド呼び出す
					break;

				case 1:
					System.out.println("どのデバイスを接続しますか？0:マウス 1:メモリー 2:カードリーダー");
					int select = new java.util.Scanner(System.in).nextInt();

					if (select == 0) {
						pc.setDevice(mo);	// マウスを引数で渡す
						System.out.println("マウス接続しました");
					} else if(select == 1) {
						pc.setDevice(me);	//メモリーを引数でわたす。
						System.out.println("メモリー接続しました");
					} else if(select == 2) {
						pc.setDevice(ca);	//カードリーダーを引数で渡す。
						System.out.println("カードリーダーを接続しました。");
					} else {
						System.out.println("番号が違います。再度入力してください");
					}

					break;

				case 2:

					if (pc.getDevice() == null) {		//deviceがnullなら接続してください
						System.out.println("接続してください");


					} else {
						System.out.println("デバイスを取り外しました");
						pc.setDevice(null);				//deviceを取り外したのでnullを入れる
					}



					break;

				case 3:
					System.out.println("アプリケーションを終了します。");
					flag = true;

			}

		}



	}

}
