package chapter07;

public interface UsbConnectable {

	void usbConnect();

}
