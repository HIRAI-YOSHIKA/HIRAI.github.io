package chapter07;

public class Main {

	public static void main(String[] args) {


	Animal[] animal = new Animal[2];		//動物でまとめた処理

	animal[0] = new Dog("柴犬", "わんわん");
	animal[1] = new Cat("タマ", "にゃーにゃー");

	for (Animal a : animal) {
		a.bark();
	}

	Plant[] plant = new Plant[2];

	plant[0] = new Rose("薔薇", "赤色");
	plant[1] = new Sunflower("ひまわり", "黄色");
	for (Plant p : plant) {
		p.makeFlowers();
	}

	Creature[] creature = new Creature[4];

	creature[0] = new Dog("柴犬", "わんわん");
	creature[1] = new Cat("タマ", "にゃーにゃー");
	creature[2] = new Rose("薔薇", "赤色");
	creature[3] = new Sunflower("ひまわり", "黄色");

	for (Creature c : creature) {
		c.live();
	}
	}

}
