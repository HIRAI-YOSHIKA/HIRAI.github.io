package chapter07;

public class Cat extends Animal {

	public Cat(String name, String voice) {
		super(name, voice);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	@Override
	public void live() {
		System.out.println(this.name + "はのんびり生活する");
	}

}
