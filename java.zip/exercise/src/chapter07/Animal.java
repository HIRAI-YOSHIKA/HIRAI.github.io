package chapter07;

public abstract class Animal implements Creature{
		//フィールド
	String name;
	String voice;

	//コンストラクタ
	public Animal(String name, String voice) {
		this.name = name;
		this.voice = voice;
	}

	//---------メソッド------------------
	/*抽象メソッド
	 */
	public abstract void live();


	public void bark() {
		System.out.println(this.name + "は" + this.voice);
	}

}
