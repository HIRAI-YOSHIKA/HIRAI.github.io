package chapter06;

public class Book {
	//ページ数
	int page;
	//価格
	int price;


	public Book(int page, int price) {
		this.page = page;
		this.price = price;
	}

	public void display() {
		System.out.println("ページ数：" + this.page);
		System.out.println("価格は：" + this.price);
	}

	public void addContent(String writing) {
		System.out.println("書き込みました");

	}




}
