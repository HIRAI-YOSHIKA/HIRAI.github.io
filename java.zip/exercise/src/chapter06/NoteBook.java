package chapter06;

public class NoteBook extends Book {


	String content;


	//--------------- フィールド変数 ------------------------

	public NoteBook(int page, int price, String content) {
		super(page, price);
		this.content = content;

	}

	public NoteBook(int page, int price) {
		super(page, price);
		this.content = "";

	}

//---------------------- コンストラクタ ------------------------------------


	/*ページ数、価格、内容を表示*/
	public void display() {
		super.display();
		System.out.println("内容：" + this.content);
	}

	/*追加の書き込みメソッド*/
	public void addContent() {

		System.out.println("書き込む内容を書いてください");
		String writing = new java.util.Scanner(System.in).next();
		this.content += writing;
		System.out.println("書き込みました");
	}

}
