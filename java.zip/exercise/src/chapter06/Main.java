package chapter06;

public class Main {

	public static void main(String[] args) {

		//本のページ
		System.out.println("本のページ数を入力してください");

		int bookPage = new java.util.Scanner(System.in).nextInt();

		//本の価格
		System.out.println("本の価格を入力してください");

		int bookPrice = new java.util.Scanner(System.in).nextInt();


		//ノートのページ
		System.out.println("ノートのページ数を入力してください");

		int notePage = new java.util.Scanner(System.in).nextInt();


		//ノートの価格
		System.out.println("ノートの価格を入力してください");

		int notePrice = new java.util.Scanner(System.in).nextInt();

		//インスタンス生成
		Book b = new Book(bookPage, bookPrice);

		NoteBook n = new NoteBook(notePage, notePrice);

		//選択画面

		boolean result = false;
		while (result == false) {
			System.out.println("1.本の情報表示   /  2.ノートの情報表示   /  3.ノートに追加書込   /  4.終了");
			int input = new java.util.Scanner(System.in).nextInt();

			switch (input) {
			case 1:
				b.display();

				break;

			case 2:
				n.display();

				break;

			case 3:

				n.addContent();

				break;

			case 4:
				System.out.println("アプリケーションを終了します");
				result = true;
			}

		}


	}

}
