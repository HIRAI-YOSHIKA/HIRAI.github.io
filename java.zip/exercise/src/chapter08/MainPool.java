package chapter08;

public class MainPool {

	public static void main(String[] args) {
	Person[] persons = new Person[100];

	String[] names = {"A","B","C","D","E","F"};

	/*for (int i = 0; persons.length; i++) {

	*/}




}
