package chapter08;

public class Main_Person {

	public static void main(String[] args) {


		int num = new java.util.Random().nextInt(1000);

		Person p = new Person(null, 0);
	}

}
