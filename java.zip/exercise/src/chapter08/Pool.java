package chapter08;

public class Pool {
/*------------------ フィールド ----------------------------------------*/

	private double water;

/*-------------------------------------------------------------------*/

/*--------------- コンストラクタ -----------------------------------------------*/
	public Pool() {

	}

/*-----------------------------------------------------------------------*/



	public double getWater() {
		return water;
	}

	public void setWater(double water) {
		this.water = water;

		if (this.water > 600) {
			this.water = 600;
		}
		if (this.water < 0) {
			this.water = 0;
		}


	}

	//引数として渡された水量を給水するメソッド
	public void feedWater(double water) {
		double poolNow = getWater();

		if (water < 0) {
			System.out.println("給水量は正の値を入れてください");
		} else {
			setWater(water + this.water);
			water = this.water - poolNow;
			System.out.println(water + "立法メートル給水致しました。");
		}

	}

	//引数として渡された水量だけ排水する
	public void drainWater(double water) {

		double poolNow = getWater();

		if (water < 0) {
			System.out.println("排水量は正の値を入れてください");

		} else {
			setWater(getWater() - water);

			System.out.println((poolNow - getWater()) + "立法メートル排水しました");


		}

	}
	//現在の水量を表示する
	public void display() {
		System.out.println("現在の水量は" + this.water + "です");
	}

}
