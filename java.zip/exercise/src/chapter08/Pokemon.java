package chapter08;

public class Pokemon {

/*------------------ フィールド変数 -----------------------------------------*/
	private String name;
	private int hp;



	/*------------------ フィールド変数 -----------------------------------------*/


/*コンストラクタ*/

	/*public Pokemon(String name, int hp) {
		for (int i = 0; i < p.length; i++){
		}
	}*/



	public Pokemon(String name, int hp) {
		this.name = name;
		this.hp = hp;
	}



	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getHp() {
		return hp;
	}


	public void setHp(int hp) {
		this.hp = hp;
	}



}
