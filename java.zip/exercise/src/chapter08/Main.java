package chapter08;

public class Main {

	public static void main(String[] args) {

		Pokemon[] p = new Pokemon[3];			//インスタンス化





		p[0] = new Pokemon("ヒトカゲ", 100);
		p[1] = new Pokemon("ゼニガメ", 50);
		p[2] = new Pokemon("フシギバナ", 200);

		for (int i = 0; i < p.length; i++) {
			for (int j = 0; j < p.length; j++) {
				if (p[j].getHp() < p[i].getHp()) {	//配列内のHPがしりたいのでgetHp()を後ろにつける

					Pokemon temp = p[i];		//参照渡し
					p[i] = p[j];
					p[j] = temp;
				}
			}
		}

		for(int i = 0; i < p.length; i++){
			System.out.println(p[i].getName() + p[i].getHp());
		}


	}

}
