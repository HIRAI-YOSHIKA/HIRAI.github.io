package chapter08;

public class Pool_Main {

	public static void main(String[] args) {


		Pool pool = new Pool();

		int input = 0;
		boolean flag = false;


		while (input != 4) {

			System.out.println("1.給水  / 2.排水  / 3.表示  / 4.終了");

			input = new java.util.Scanner(System.in).nextInt();

			switch (input) {
				case 1:
					System.out.println("給水する水量を入力して下さい");
					double feed = new java.util.Scanner(System.in).nextDouble();
					pool.feedWater(feed);
					break;
				case 2:
					System.out.println("排水する水量を入力してください");
					double drain = new java.util.Scanner(System.in).nextDouble();
					pool.drainWater(drain);
					break;

				case 3:
					pool.display();
					break;


				case 4:
					System.out.println("アプリケーションを終了します");
					flag = true;
					break;
			}

		}
	}

}
