package chapter03;

public class Q08 {

	public static void main(String[] args) {
		System.out.println("価格を入力してください");
		int perc = new java.util.Scanner(System.in).nextInt();

		tax(perc);

	}
	public static void tax(int x) {


		 double ans1 = x + (x * 0.1);
		 int ans = (int)ans1;

		System.out.println("100円は消費税込みで" + ans + "です");
	}

}
