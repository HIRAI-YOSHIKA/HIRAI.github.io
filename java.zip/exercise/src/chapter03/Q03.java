package chapter03;

public class Q03 {

	public static void main(String[] args) {
		System.out.println("整数を入れてください");
		int ans = new java.util.Scanner(System.in).nextInt();

		value(ans);


	}
	public static int value(int num) {

		int answ  = num  * num * num;

		System.out.println(num + "を3乗すると" + answ);

		return answ;
	}
}
