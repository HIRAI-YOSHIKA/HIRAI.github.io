package chapter03;

public class Q02 {

	public static void main(String[] args) {
		System.out.println("お名前を入力してください");
		String name = new java.util.Scanner(System.in).nextLine();

		System.out.println("年齢を入れてください" );
		int age = new java.util.Scanner(System.in).nextInt();

		method(name, age);



	}
	public static void method(String x, int y) {

		System.out.println(x + "(" + y +")" + "さん、こんにちは！ ");

	}

}
