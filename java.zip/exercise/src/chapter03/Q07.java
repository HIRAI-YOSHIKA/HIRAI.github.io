package chapter03;

public class Q07 {

	public static void main(String[] args) {
		System.out.println("名前を入力してください");
		String name = new java.util.Scanner(System.in).nextLine();
		greeting(name);

	}
	public static void greeting(String name) {
		System.out.println(name + "さん、こんにちは！");

	}

}
