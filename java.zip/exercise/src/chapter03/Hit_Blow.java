package chapter03;

public class Hit_Blow {

	public static void main(String[] args) {
		System.out.println("Hit&Blowを始めます");

		int [] number1 = new int[4];
		int [] number2 = new int[4];
		for(int i = 0; i < number1.length; i++) {
			number1[i] = new java.util.Random().nextInt(10);


			for(int j = 0; j < number1.length; j++) {

				if(number1[i] == number1.length - 1) {

				}
			}

		}
		/*for(int value : number) {
			System.out.print(value);
		}*/
	}

}
