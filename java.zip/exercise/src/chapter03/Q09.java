package chapter03;

public class Q09 {

	public static void main(String[] args) {
		System.out.println("整数1を入れてください");
		int x = new java.util.Scanner(System.in).nextInt();

		System.out.println("整数2を入れてください");
		int y = new java.util.Scanner(System.in).nextInt();

		int ans = aver(x, y);

		System.out.println("2つの整数値の平均は" + ans + "です");
	}
	public static int aver(int x, int y) {

		double ans1 = (x + y) / 2;

		int ans = (int)ans1;

		return ans;
	}

}
