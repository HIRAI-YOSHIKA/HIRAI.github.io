package chapter03;

public class Q06 {

	public static void main(String[] args) {
		hello();

	}
	public static void hello() {
		System.out.println("Hello!");

	}

}
