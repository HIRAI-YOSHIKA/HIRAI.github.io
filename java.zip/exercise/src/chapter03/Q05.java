package chapter03;

public class Q05 {

	public static void main(String[] args) {
		System.out.println("1からいくつ足しますか");
		int num = new java.util.Scanner(System.in).nextInt();
		int ans = add(num);
		System.out.println("1から" + num + "の和は" + ans + "です");

	}//main

	public static int add(int value) {

		//合計値の格納する変数用意
		int sum = 0;

		//合計値の計算をfor文で行う
		for(int i = 0; i <= value; i++) {
			sum += i;
		}

		//合計値をmainに返す
		return sum;

	}//add

}
