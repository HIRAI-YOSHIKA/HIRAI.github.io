package chapter03;

public class Q10 {

	public static void main(String[] args) {
		System.out.println("整数をいれてください");
		int value = new java.util.Scanner(System.in).nextInt();
		String text = "奇数";
		String text1 = "偶数";
		boolean  resalt = even(value);

		if(resalt == true) {
			System.out.println(value + "は" + text + "です");
		} else {
			System.out.println("偶数");
			System.out.println(value + "は" + text1 + "です");
		}


//		System.out.println(value + "は" + texe + "です");

	}
	public static boolean even(int value) {
		boolean result;


		if (value % 2 != 0) {


			result = true;

		} else {

			result = false;

		}




		return result;
	}

}
