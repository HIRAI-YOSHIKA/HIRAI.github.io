package chapter03;

public class Q04 {

	public static int max(int ansx, int ansy, int ansz) {
		int box = 0;

		if(ansx < ansy) {
			box = ansx;
			ansx = ansy;
			ansy = box;
		}//if
		if(ansx < ansz) {
			box = ansx;
			ansx = ansz;
			ansz = box;
		}//if
		if(ansy < ansz) {
			box = ansy;
			ansy = ansz;
			ansz = box;
		}

		int value = ansx;

		return value;
	}//max

	public static void main(String[] args) {
		int value;

		System.out.println("整数1を入れてください");
		int x = new java.util.Scanner(System.in).nextInt();

		System.out.println("整数2を入れてください");
		int y = new java.util.Scanner(System.in).nextInt();

		System.out.println("整数3を入れてください");
		int z = new java.util.Scanner(System.in).nextInt();

		int ans = max(x, y, z);



		System.out.println("3つの整数値の最大は" + ans);
	}//main

}//class
