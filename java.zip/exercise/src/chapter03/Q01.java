package chapter03;

public class Q01 {

	public static void main(String[] args) {
		initGame();
		runGame();
		endGame();


	}
	public static void initGame() {
		System.out.println("initGame");
	}
	public static void runGame() {
		System.out.println("runGame");
	}
	public static void endGame() {
		System.out.println("endGame");
	}
}
