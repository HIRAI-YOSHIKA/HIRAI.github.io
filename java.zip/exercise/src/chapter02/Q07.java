package chapter02;

public class Q07 {

	public static void main(String[] args) {
		System.out.println("何人ですか？");
		int x = new java.util.Scanner(System.in).nextInt();

		int[] value = new int[x];
		int sum =0;

		for (int i = 0; i < x; i++) {

			System.out.println((i + 1) + "人目の点数を入力してください");		//iは現在何人目かを表す
			value[i]  = new java.util.Scanner(System.in).nextInt();				//配列に入力された数字を格納する
			sum += value[i];
		}




	/*	System.out.println("二人目の点数を入力してください");
		int nums2 = new java.util.Scanner(System.in).nextInt();*/

		System.out.println(x + "人の合計点数は" + sum + "です");

	}

}
