package chapter02;

public class Q10 {

	public static void main(String[] args) {

		int[] nums = {3, 8, 10, 5, 4};
		//int [] value = new int[5];

		for (int i = 0; i < nums.length / 2; i++) {
			int j = nums.length - 1 -i;	    // 配列の最後から内側に減る

			int z = nums[i];
			nums[i] = nums[j];
			nums[j] = z;

		}
		for (int value : nums) {
			System.out.println(value);
		}

	}
}
