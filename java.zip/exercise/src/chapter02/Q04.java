package chapter02;

public class Q04 {

	public static void main(String[] args) {

	char[] i = {'H', 'E', 'L', 'L', 'O', '!'};


		for(char z : i) {
			System.out.print(z);
		}

	}

}
