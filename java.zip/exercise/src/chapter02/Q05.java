package chapter02;

public class Q05 {

	public static void main(String[] args) {

		boolean[] games = {true, false, false, true, true};

		System.out.println("第何戦の結果を調べますか（1～5）＞");

		int input = new java.util.Scanner(System.in).nextInt();


		if(games[input - 1] == true) {
			System.out.println("第" + input + "戦は勝ち");
		} else {
			System.out.println("第" + input + "戦は負け");
		}


	}

}
