package chapter02;

public class Q03 {

	public static void main(String[] args) {

		double[] i = {22.3, 33.1, 11.5};
		i[0] = 22.5;

		System.out.println("最初の要素" + i[0] + "をに変更しました");

	}

}
