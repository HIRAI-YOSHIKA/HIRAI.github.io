package chapter02;

public class Q02 {

	public static void main(String[] args) {


		 String[] i = {"Banana", "Apple", "Orange"};


		 System.out.println("Fruits[0]:" + i[0] + " Fruits[1]:" + i[1] + " Fruits[2]:" + i[2]);
	}


}
