package chapter02;

public class Q01 {

	public static void main(String[] args) {

		int[] nums = new int[3];

		nums[0] = 30;
		nums[1] = 70;
		nums[2] = 10;


		System.out.println("nums[0]:" + nums[0] + "nums1:" + nums[1] + "nums[2]:" + nums[2]);

	}

}
