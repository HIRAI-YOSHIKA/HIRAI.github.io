package chapter02;

public class Q06 {

	public static void main(String[] args) {

		int[] nums = new int[5];

		/*nums[0] = new java.util.Random().nextInt(101);
		nums[1] = new java.util.Random().nextInt(101);
		nums[2] = new java.util.Random().nextInt(101);
		nums[3] = new java.util.Random().nextInt(101);
		nums[4] = new java.util.Random().nextInt(101);*/


		for(int i = 0; i < nums.length; i++) {

			nums[i] = new java.util.Random().nextInt(101);	//乱数を配列に入れる

		}

		for(int i = 0; i < nums.length; i++) {				//配列内の値を順番に

			System.out.println(nums[i]);					//出力する


		}



	}

}
