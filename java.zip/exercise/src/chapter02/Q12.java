package chapter02;

public class Q12 {

	public static void main(String[] args) {

		int[] numbers = new int[100];
		int num = 77;
		int index = 0;
		boolean flag = false;

		for (int i =0; i < numbers.length; i++) {

			numbers[i] = new java.util.Random().nextInt(100) + 1;
			index++;
			System.out.println(numbers[i]);

			if (numbers[i] == num) {
				System.out.println("インデックス" + index + "が" + numbers[i] + "です");
				flag = true;
				break;
			}



		}
		if (flag == false) {
			System.out.println("含まれない");

		}


	}

}
