package chapter02;

public class Q11 {

	public static void main(String[] args) {
		int[] nums = {3, 8, 10, 5, 4};

		for (int i = 0; i < nums.length; i++) {
			for (int k = 0; k < nums.length; k++) {

				if (nums[i] < nums[k]) {
					int box = nums[i];
					nums[i] = nums[k];
					nums[k] = box;

				}
			}

		}
		for (int i = 0; i < nums.length; i++) {
			System.out.println(nums[i]);
		}
	}

}
