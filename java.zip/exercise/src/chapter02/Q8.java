package chapter02;

public class Q8 {

	public static void main(String[] args) {
		int[] nums = {3, 8, 10, 5, 4};

		for (int i = 0; i < nums.length; i++) {
			if ((nums[i] % 2) == 1) {
				System.out.println("奇数は" + nums[i] + "です");

			}

		}

	}

}
