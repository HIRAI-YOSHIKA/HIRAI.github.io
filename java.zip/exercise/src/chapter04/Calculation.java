package chapter04;

public class Calculation {

	public static int tasu(int a, int b) {//Q1



		return (a + b);

	}//Q1ここまで
	public static int hiku(int x, int y) {//Q2

		return (x - y);
	}//Q2ここまで

	public static boolean evenumberJudge(int x) {//3


		return (false);
	}//Q3ここまで

	public static boolean findNumber(int num) {
		return(true);
	} //Q4ここまで

	public static int[] arrayGeneration(int x) {
		//x個の要素数をもつ配列変数arrayを宣言
		int[] array = new int[x];

		//iはインデックスの数字
		//iに乱数を代入するfor文
		for(int i = 0; i < array.length; i++) {
			// 乱数を作成 1～100
			int ram = new java.util.Random().nextInt(100)+1;

			// 乱数を各要素に代入
			array[i] = ram;
		}

		return array;
	}


}
