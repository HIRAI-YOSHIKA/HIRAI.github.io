package chapter04;


public class Main_Q1_5 {

	public static void main(String[] args) {

		int a = 2;
		int b = 3;

		int total = Calculation.tasu(a, b);

		System.out.println(a + "+" + b + "=" + total );

		//Q1終わり

		System.out.println("一つ目の整数を入力してください");
		int input1 = new java.util.Scanner(System.in).nextInt();

		System.out.println("二つ目の整数を入力してください");
		int input2 = new java.util.Scanner(System.in).nextInt();


		int delta = Calculation.hiku(input1, input2);

		System.out.println(input1 + "-" + input2 + "=" + delta);

		//Q2おわり

		System.out.println("偶数か奇数かを判定します");
		System.out.println("整数1つを入力してください");

		int x = new java.util.Scanner(System.in).nextInt();

		boolean Ans1 = Calculation.evenumberJudge(x);


		if ((x %= 2) == 0) {
			System.out.println("偶数です");
			boolean Ans2 = true;

		} else {
			System.out.println("奇数です");
		}//Q3終わり



		System.out.println("1つの2桁の整数を入力してください");

		int num = new java.util.Scanner(System.in).nextInt();

		boolean numAns = Calculation.findNumber(num);



			for (int i = 0; i < 100; i++) {
				int ram = new java.util.Random().nextInt(101);

				ram += i;


				if (numAns) {

				System.out.println(ram + "回目に" + num + "を発見！ループを止めます");
				break;
				} else {
				System.out.println("見つかりませんでした");
				}

			}//Q4でおわり

			System.out.println("配列の要素数を入力してください");
			int element = new java.util.Scanner(System.in).nextInt();


			int[] array = Calculation.arrayGeneration(element);

			for (int value : array) {
				System.out.println(value);
			}





	}

}//Q1_5nain終わり
