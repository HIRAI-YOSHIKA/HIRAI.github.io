package chapter04;

public class Main_Q6_9 {

	public static void main(String[] args) {

		System.out.println("四角形の面積を求めます");

		System.out.println("縦の長さを整数で入力してください");
		int vertical = new java.util.Scanner(System.in).nextInt();

		System.out.println("横の長さを整数で入力してください");
		int horizontal = new java.util.Scanner(System.in).nextInt();

		int result = ShapeLogic.square(vertical, horizontal);
		System.out.println("縦が"+ vertical + "横が" + horizontal + "の四角形の面積は"+ result);




		System.out.println("三角形の面積を求めます");

		System.out.println("底辺を整数で入力してください");
		int bottom = new java.util.Scanner(System.in).nextInt();

		System.out.println("高さを整数で入力してください");
		int height = new java.util.Scanner(System.in).nextInt();

		int result1 = ShapeLogic.triangle(bottom, height);
		System.out.println("底辺が"+ bottom + "高さが" + height + "の三角形の面積は"+ result1);



		System.out.println("台形の面積を求めます");

		System.out.println("上底を整数で入力してください");
		int upperSide = new java.util.Scanner(System.in).nextInt();

		System.out.println("下底を整数で入力してください");
		int underSide = new java.util.Scanner(System.in).nextInt();

		System.out.println("高さを入力してください");
		int height1 = new java.util.Scanner(System.in).nextInt();

		int result2 = ShapeLogic.trapezoid(upperSide, underSide, height1);
		System.out.println("上底が" + upperSide + "、" + "下底が" + underSide + "、" + "高さが"+ height1 + " + " + "台形の面積は" + result2);
	}

}
